// Painel /config — todas as páginas em Components V2, sem digitar IDs.
const { ChannelType } = require('discord.js');
const store = require('./storage');
const ui = require('./ui');
const templates = require('./templates');
const security = require('./security');
const moderation = require('./moderation');
const honeypot = require('./honeypot');
const announcements = require('./announcements');
const ai = require('./ai');
const tickets = require('./tickets');
const { hasPerm } = require('./permissions');
const { log } = require('./logs');
const { OWNER_ID, PERMS, LOG_KINDS } = require('./constants');
const { uid, trunc, BRL, isUrl, ts } = require('./util');

const TEXT = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const { page, row, btn, strSel, roleSel, chanSel, userSel, modal } = ui;
const back = (to = 'cfg:home', label = '← Voltar') => btn(to, label);
const onoff = (v) => (v ? '✅ Ativado' : '❌ Desativado');
const mention = (id) => (id ? `<#${id}>` : '*não definido*');
const full = (i) => hasPerm(i.guildId, i.member, i.user.id, 'config');
const canMod = (i) => hasPerm(i.guildId, i.member, i.user.id, 'moderation');
const ACTION_LABEL = { delete: 'Apenas excluir mensagem', warn: 'Advertência (DM + registro)', timeout: 'Timeout (castigo)', kick: 'Expulsar', ban: 'Banir' };
const int = (s, min, max, def) => {
  const n = parseInt(String(s).trim(), 10);
  return Number.isFinite(n) ? Math.min(Math.max(n, min), max) : def;
};

// ================= HOME =================
const SECTIONS = [
  ['general', '🔑 Permissões e canais de log'], ['tickets', '🎫 Tickets'], ['shop', '🛒 Loja e produtos'], ['feedbacks', '⭐ Feedbacks'],
  ['moderation', '⚖️ Moderação'], ['security', '🛡️ Segurança'], ['honeypot', '🍯 Honeypot'], ['ai', '🤖 Inteligência artificial'],
  ['welcome', '👋 Boas-vindas e saída'], ['ann', '📢 Avisos e anúncios'], ['rules', '📜 Regras'], ['backup', '💾 Backup'],
];
function home(i) {
  const g = i.guildId;
  const isFull = full(i);
  const t = store.get(g, 'tickets');
  const sec = Object.keys(security.RULES).filter((k) => security.rule(g, k).enabled).length;
  const w = store.get(g, 'welcome');
  const text = isFull
    ? [
        `🎫 **Tickets:** ${onoff(t.settings.enabled)} • modo ${t.settings.mode === 'thread' ? 'tópicos' : 'canais privados'} • ${Object.keys(t.panels).length} painel(is) • ${Object.keys(t.categories).length} categoria(s)`,
        `🛒 **Loja:** ${Object.keys(store.get(g, 'shop').products).length} produto(s)`,
        `⭐ **Feedbacks:** ${onoff(store.get(g, 'feedback').settings.enabled)} • ${store.get(g, 'feedback').entries.length} registro(s)`,
        `🛡️ **Segurança:** ${sec}/${Object.keys(security.RULES).length} proteções ativas`,
        `🍯 **Honeypot:** ${onoff(store.get(g, 'honeypot').enabled)}`,
        `🤖 **IA:** chave ${ai.hasKey() ? '✅ configurada' : '❌ ausente (Secrets)'}`,
        `👋 **Boas-vindas:** ${onoff(w.join.enabled)} • **Saída:** ${onoff(w.leave.enabled)}`,
        `📢 **Avisos:** ${Object.keys(store.get(g, 'announcements').items).length}`,
      ].join('\n')
    : 'Você tem acesso ao módulo de **Moderação**.';
  const opts = SECTIONS.filter(([k]) => isFull || k === 'moderation').map(([value, label]) => ({ label, value }));
  return page({ title: '⚙️ Painel ZYPhor', text, rows: [row(strSel('cfg:nav', 'Escolha um módulo para configurar…', opts))], footer: 'Tudo é salvo automaticamente em JSON.' });
}

// ================= GERAL =================
function general(i, [perm = 'config'] = []) {
  const g = i.guildId;
  const core = store.get(g, 'core');
  const current = Object.entries(core.permissions).filter(([, p]) => p.includes(perm)).map(([r]) => r);
  const lines = Object.entries(PERMS).map(([k, v]) => {
    const rs = Object.entries(core.permissions).filter(([, p]) => p.includes(k)).map(([r]) => `<@&${r}>`);
    return `**${k}** — ${v}: ${rs.join(' ') || '*nenhum cargo*'}`;
  });
  const own = i.user.id === OWNER_ID;
  return page({
    title: '🔑 Permissões da equipe',
    text: `O proprietário principal (<@${OWNER_ID}>) sempre tem acesso total. \`config\` concede acesso a tudo.\n\n${lines.join('\n')}\n\n**Editando:** \`${perm}\`${perm === 'config' && !own ? '\n⚠️ Só o proprietário principal altera o cargo \`config\`.' : ''}`,
    rows: [
      row(strSel('cfg:general_perm', 'Escolha a permissão para editar', Object.entries(PERMS).map(([k, v]) => ({ label: k, value: k, description: v, default: k === perm })))),
      row(roleSel(`cfg:s_perm:${perm}`, `Cargos com a permissão "${perm}"`, current)),
      row(btn('cfg:logs', '📋 Canais de log', { style: 'primary' }), back()),
    ],
  });
}
function logs(i, [kind = 'tickets'] = []) {
  const core = store.get(i.guildId, 'core');
  const lines = Object.entries(LOG_KINDS).map(([k, v]) => `**${v}:** ${mention(core.logs[k])}`);
  return page({
    title: '📋 Canais de log',
    text: `Todos os registros também são guardados em JSON.\n\n${lines.join('\n')}\n\n**Editando:** ${LOG_KINDS[kind]}`,
    rows: [
      row(strSel('cfg:logs_kind', 'Tipo de registro', Object.entries(LOG_KINDS).map(([k, v]) => ({ label: v, value: k, default: k === kind })))),
      row(chanSel(`cfg:s_log:${kind}`, 'Canal de destino', TEXT, core.logs[kind] ? [core.logs[kind]] : [])),
      row(btn(`cfg:s_logclear:${kind}`, 'Remover canal', { style: 'danger' }), back('cfg:general', '← Permissões')),
    ],
  });
}

// ================= TICKETS =================
function ticketsPage(i) {
  const d = store.get(i.guildId, 'tickets');
  const s = d.settings;
  const thread = s.mode === 'thread';
  return page({
    title: '🎫 Tickets',
    text: [
      `**Sistema:** ${onoff(s.enabled)}`,
      `**Modo:** ${thread ? 'Threads/tópicos privados' : 'Canais privados'}`,
      `**Destino:** ${thread ? mention(s.destination) : s.destination ? `categoria <#${s.destination}>` : '*sem categoria (raiz do servidor)*'}`,
      `**Categorias:** ${Object.keys(d.categories).length} • **Painéis:** ${Object.keys(d.panels).length} • **Abertos:** ${Object.keys(d.open).length}`,
      '',
      thread ? '-# Em tópicos privados o Discord não permite adicionar cargos: a equipe é marcada na abertura e quem tem *Gerenciar Tópicos* enxerga todos. Convites estão desativados para o cliente.' : '-# Em canais privados só cliente, equipe da categoria e participantes adicionados enxergam o canal.',
    ].join('\n'),
    rows: [
      row(btn('cfg:s_tk_toggle', s.enabled ? 'Desativar' : 'Ativar', { style: s.enabled ? 'danger' : 'success' }), btn('cfg:s_tk_mode', `Modo: ${thread ? 'Tópicos' : 'Canais'} (alternar)`), btn('cfg:tkcats', 'Categorias', { style: 'primary' }), btn('cfg:tkpanels', 'Painéis', { style: 'primary' }), back()),
      row(chanSel('cfg:s_tk_dest', thread ? 'Canal onde os tópicos serão criados' : 'Categoria onde os canais serão criados', thread ? TEXT : [ChannelType.GuildCategory], s.destination ? [s.destination] : [])),
    ],
  });
}
function tkcats(i, [sel] = []) {
  const d = store.get(i.guildId, 'tickets');
  const cats = Object.values(d.categories);
  if (!d.categories[sel]) sel = null;
  const c = sel && d.categories[sel];
  const text = c
    ? `**${c.emoji || ''} ${c.name}** — ${c.type === 'shop' ? '🛒 tipo Loja (mostra produtos)' : 'atendimento normal'}\n${c.description || ''}\n**Cargos responsáveis:** ${c.roleIds.map((r) => `<@&${r}>`).join(' ') || '*nenhum (usa permissões gerais)*'}\n**Perguntas:** ${c.questions.length ? '\n' + c.questions.map((q, k) => `${k + 1}. ${q}`).join('\n') : '*nenhuma*'}`
    : cats.length ? 'Selecione uma categoria ou crie uma nova.' : 'Nenhuma categoria ainda. Crie a primeira!';
  return page({
    title: '🗂️ Categorias de atendimento',
    text,
    rows: [
      cats.length ? row(strSel('cfg:tkcat_sel', 'Selecione uma categoria', cats.map((x) => ({ label: x.name, value: x.id, emoji: x.emoji, default: x.id === sel })))) : null,
      c ? row(roleSel(`cfg:s_tkcat_roles:${c.id}`, 'Cargos responsáveis por esta categoria', c.roleIds)) : null,
      row(btn('cfg:tkcat_new', 'Nova', { style: 'success' }), btn(`cfg:tkcat_edit:${sel}`, 'Editar', { disabled: !c }), btn(`cfg:tkq:${sel}`, 'Perguntas', { disabled: !c }), btn(`cfg:s_tkcat_del:${sel}`, 'Remover', { style: 'danger', disabled: !c }), back('cfg:tickets')),
    ],
  });
}
const catModal = (id, c) => modal(`cfg:s_tkcat_m:${id}`, id === 'new' ? 'Nova categoria' : 'Editar categoria', [
  { id: 'name', label: 'Nome', max: 80, value: c?.name },
  { id: 'emoji', label: 'Emoji (opcional)', required: false, max: 60, value: c?.emoji },
  { id: 'desc', label: 'Descrição (opcional)', required: false, max: 100, value: c?.description },
  { id: 'type', label: 'Tipo: normal ou loja', required: false, max: 10, value: c?.type === 'shop' ? 'loja' : 'normal' },
]);
function tkpanels(i) {
  const d = store.get(i.guildId, 'tickets');
  const ps = Object.values(d.panels);
  return page({
    title: '📩 Painéis de abertura',
    text: ps.length ? ps.map((p) => `• **${p.name}** — ${p.messageId ? `publicado em ${mention(p.messageChannelId)}` : 'não publicado'}`).join('\n') : 'Nenhum painel. Crie um e publique no canal desejado.',
    rows: [ps.length ? row(strSel('cfg:tkpanel_sel', 'Selecione um painel', ps.map((p) => ({ label: p.name, value: p.id })))) : null, row(btn('cfg:tkpanel_new', 'Novo painel', { style: 'success' }), back('cfg:tickets'))],
  });
}
function tkpanel(i, [id] = []) {
  const d = store.get(i.guildId, 'tickets');
  const p = d.panels[id];
  if (!p) return tkpanels(i);
  const cats = Object.values(d.categories);
  return page({
    title: `📩 Painel: ${p.name}`,
    text: `**Estilo:** ${p.style === 'select' ? 'Menu de seleção' : 'Botões'}\n**Canal:** ${mention(p.channelId)}\n**Categorias:** ${p.categoryIds.map((c) => d.categories[c]?.name).filter(Boolean).join(', ') || '*nenhuma*'}\n**Publicado:** ${p.messageId ? 'sim' : 'não'}`,
    rows: [
      row(chanSel(`cfg:s_tkpanel_chan:${id}`, 'Canal de publicação', TEXT, p.channelId ? [p.channelId] : [])),
      cats.length ? row(strSel(`cfg:s_tkpanel_cats:${id}`, 'Categorias exibidas neste painel', cats.map((c) => ({ label: c.name, value: c.id, emoji: c.emoji, default: p.categoryIds.includes(c.id) })), { min: 0, max: Math.min(cats.length, 25) })) : null,
      row(btn(`tpl:main:ticket.panel.${id}`, '🎨 Aparência', { style: 'primary' }), btn(`cfg:s_tkpanel_style:${id}`, `Estilo: ${p.style === 'select' ? 'Menu' : 'Botões'}`), btn(`tpl:pub:ticket.panel.${id}`, 'Publicar', { style: 'success' }), btn(`cfg:s_tkpanel_del:${id}`, 'Remover', { style: 'danger' }), back('cfg:tkpanels')),
    ],
  });
}

// ================= LOJA =================
function shopPage(i, [sel] = []) {
  const g = i.guildId;
  const d = store.get(g, 'shop');
  const ps = Object.values(d.products);
  const p = d.products[sel];
  const cats = Object.values(store.get(g, 'tickets').categories);
  const text = p
    ? `**${p.name}** — ${BRL(p.price)}\n${trunc(p.description || '*sem descrição*', 400)}\n**Imagem:** ${p.image ? '✅' : '—'}\n**Cargos entregues:** ${p.roleIds.map((r) => `<@&${r}>`).join(' ') || '*nenhum (entrega manual)*'}\n**Destino do ticket:** ${p.categoryId && store.get(g, 'tickets').categories[p.categoryId] ? store.get(g, 'tickets').categories[p.categoryId].name : 'categoria de onde a compra foi iniciada'}\n**Botões extras:** ${p.buttons.map((b) => b.label).join(', ') || '—'}`
    : `${ps.length} produto(s). O cliente escolhe o produto dentro de uma categoria do tipo **Loja** de um painel de tickets — nenhum card de venda é publicado. O pagamento é confirmado manualmente pela equipe.`;
  return page({
    title: '🛒 Loja e produtos',
    text,
    rows: [
      ps.length ? row(strSel('cfg:shop_sel', 'Selecione um produto', ps.map((x) => ({ label: x.name, value: x.id, description: BRL(x.price), default: x.id === sel })))) : null,
      p ? row(roleSel(`cfg:s_prod_roles:${p.id}`, 'Cargos entregues na compra', p.roleIds)) : null,
      p ? row(strSel(`cfg:s_prod_cat:${p.id}`, 'Destino do ticket (categoria de atendimento)', [{ label: 'Padrão (categoria de origem)', value: '__default', default: !p.categoryId }, ...cats.map((c) => ({ label: c.name, value: c.id, default: p.categoryId === c.id }))])) : null,
      row(btn('cfg:prod_new', 'Novo', { style: 'success' }), btn(`cfg:prod_edit:${sel}`, 'Editar', { disabled: !p }), btn(`cfg:prod_btns:${sel}`, 'Botões', { disabled: !p }), btn(`cfg:s_prod_del:${sel}`, 'Remover', { style: 'danger', disabled: !p }), back()),
      row(btn('cfg:deliveries', '📦 Compras e entregas')),
    ],
  });
}
const prodModal = (id, p) => modal(`cfg:s_prod_m:${id}`, id === 'new' ? 'Novo produto' : 'Editar produto', [
  { id: 'name', label: 'Nome', max: 80, value: p?.name },
  { id: 'price', label: 'Preço fixo (ex.: 29,90)', max: 12, value: p ? String(p.price).replace('.', ',') : '' },
  { id: 'desc', label: 'Descrição', paragraph: true, required: false, max: 1500, value: p?.description },
  { id: 'image', label: 'Imagem (URL, opcional)', required: false, max: 500, value: p?.image },
]);
function deliveries(i) {
  const d = store.get(i.guildId, 'shop').deliveries.slice(-8).reverse();
  return page({ title: '📦 Entregas recentes', text: d.length ? d.map((x) => `ticket #${x.ticket} • **${x.productName}** (${BRL(x.price)}) → <@${x.userId}> • por <@${x.by}> • ${x.complete ? '✅' : '⚠️ parcial'} • ${ts(x.at)}`).join('\n') : 'Nenhuma entrega registrada.', rows: [row(back('cfg:shop', '← Loja'))] });
}

// ================= FEEDBACKS =================
function feedbacksPage(i) {
  const d = store.get(i.guildId, 'feedback');
  const avg = d.entries.length ? (d.entries.reduce((s, e) => s + e.stars, 0) / d.entries.length).toFixed(2) : '—';
  return page({
    title: '⭐ Feedbacks',
    text: `**Sistema:** ${onoff(d.settings.enabled)}\n**Canal de publicação:** ${mention(d.settings.channelId)}\n**Registros:** ${d.entries.length} • **Média:** ${avg}\n\nA equipe consulta com **z!feedbacks** (permissão \`feedbacks\`), com filtro por produto.`,
    rows: [
      row(chanSel('cfg:s_fb_chan', 'Canal onde os feedbacks serão publicados', TEXT, d.settings.channelId ? [d.settings.channelId] : [])),
      row(btn('cfg:s_fb_toggle', d.settings.enabled ? 'Desativar' : 'Ativar', { style: d.settings.enabled ? 'danger' : 'success' }), btn('tpl:main:feedback.request', '🎨 Mensagem da DM', { style: 'primary' }), back()),
    ],
  });
}

// ================= MODERAÇÃO =================
function moderationPage(i) {
  const d = store.get(i.guildId, 'moderation');
  const rec = moderation.recent(i.guildId, 6);
  const isFull = full(i);
  return page({
    title: '⚖️ Moderação',
    text: `**DM ao punido:** ${onoff(d.settings.dm)}\n\n**Últimos registros:**\n${rec.length ? rec.map(moderation.line).join('\n') : '*nenhum*'}`,
    rows: [
      row(btn('cfg:mod_apply', 'Punir', { style: 'danger' }), btn('cfg:mod_unban', 'Remover ban'), btn('cfg:mod_clear', 'Limpar mensagens'), btn('cfg:mod_hist', 'Histórico')),
      isFull ? row(btn('cfg:s_mod_dm', d.settings.dm ? 'DM: ligada' : 'DM: desligada'), btn('cfg:mod_msgs', 'Mensagens de punição'), back()) : row(back()),
    ],
  });
}
function modApply(i) {
  return page({ title: '⚖️ Punir membro', text: 'Escolha o membro:', rows: [row(userSel('cfg:mod_user', 'Selecione o membro')), row(back('cfg:moderation'))] });
}
function modMsgs(i) {
  const d = store.get(i.guildId, 'moderation');
  return page({
    title: '✉️ Mensagens de punição (DM)',
    text: 'Variáveis: {user} {username} {server} {reason} {moderator} {type} {duration}\n\n' + ['warn', 'timeout', 'kick', 'ban'].map((t) => `**${moderation.TYPES[t]}:** ${trunc(d.settings.messages[t] || moderation.DEFAULT_MSG[t], 150)}`).join('\n'),
    rows: [row(strSel('cfg:mod_msg_sel', 'Editar mensagem de…', ['warn', 'timeout', 'kick', 'ban'].map((t) => ({ label: moderation.TYPES[t], value: t })))), row(back('cfg:moderation'))],
  });
}

// ================= SEGURANÇA =================
function securityPage(i) {
  const g = i.guildId;
  const lines = Object.entries(security.RULES).map(([k, R]) => `${security.rule(g, k).enabled ? '✅' : '❌'} **${R.name}** — ${R.desc}`);
  const hp = store.get(g, 'honeypot');
  return page({
    title: '🛡️ Segurança',
    text: `${lines.join('\n')}\n${hp.enabled ? '✅' : '❌'} **Honeypot** — canal armadilha\n\n-# A IA nunca bane ou pune sozinha. Punições automáticas vêm apenas das regras acima.`,
    rows: [row(strSel('cfg:sec_sel', 'Configurar proteção…', [...Object.entries(security.RULES).map(([k, R]) => ({ label: R.name, value: k, description: R.desc })), { label: 'Honeypot', value: '__hp', description: 'Canal armadilha', emoji: '🍯' }])), row(back())],
  });
}
function secRule(i, [key]) {
  const R = security.RULES[key];
  if (!R) return securityPage(i);
  const g = i.guildId;
  const r = security.rule(g, key);
  const info = [`**Status:** ${onoff(r.enabled)}`, `**Ação:** ${ACTION_LABEL[r.action]}${r.action === 'timeout' ? ` (${r.timeoutMin} min)` : ''}`];
  if (R.fields.includes('limit')) info.push(`**Limite:** ${r.limit}`);
  if (R.fields.includes('windowSec')) info.push(`**Tempo de detecção:** ${r.windowSec}s`);
  if (key === 'fake') info.push(`**Idade mínima:** ${r.minAgeDays} dia(s) • **Exigir avatar:** ${r.noAvatar ? 'sim' : 'não'}`);
  if (key === 'link') info.push(`**Domínios permitidos:** ${r.allowedDomains.join(', ') || '*nenhum*'}`);
  if (key === 'phishing') info.push(`**Domínios bloqueados extras:** ${r.blockedDomains.join(', ') || '*nenhum* (heurísticas internas sempre ativas)'}`);
  if (key === 'bot') info.push(`**Bots permitidos:** ${r.allowedBots.map((b) => `<@${b}>`).join(' ') || '*nenhum*'}`);
  info.push(`**Cargos isentos:** ${r.exemptRoles.map((x) => `<@&${x}>`).join(' ') || '—'}`);
  if (R.kind === 'msg') info.push(`**Canais isentos:** ${r.exemptChannels.map((x) => `<#${x}>`).join(' ') || '—'}`);
  const actions = (R.kind === 'msg' ? security.MSG_ACTIONS : security.JOIN_ACTIONS).map((a) => ({ label: ACTION_LABEL[a], value: a, default: r.action === a }));
  const third = key === 'link' || key === 'phishing' ? btn(`cfg:sec_adv:${key}`, 'Domínios') : key === 'fake' ? btn('cfg:s_sec_noavatar', `Avatar obrigatório: ${r.noAvatar ? 'sim' : 'não'}`) : null;
  return page({
    title: `🛡️ ${R.name}`,
    text: info.join('\n'),
    rows: [
      row(btn(`cfg:s_sec_toggle:${key}`, r.enabled ? 'Desativar' : 'Ativar', { style: r.enabled ? 'danger' : 'success' }), btn(`cfg:sec_lim:${key}`, 'Limites', { disabled: !R.fields.length }), third, btn(`cfg:sec_events:${key}`, 'Ocorrências'), back('cfg:security')),
      row(strSel(`cfg:s_sec_action:${key}`, 'Ação ao detectar', actions)),
      row(roleSel(`cfg:s_sec_roles:${key}`, 'Cargos isentos', r.exemptRoles)),
      R.kind === 'msg' ? row(chanSel(`cfg:s_sec_chans:${key}`, 'Canais isentos', TEXT, r.exemptChannels, { min: 0, max: 25 })) : null,
      key === 'bot' ? row(userSel('cfg:s_sec_bots', 'Bots permitidos', { min: 0, max: 10, selected: r.allowedBots })) : null,
    ],
  });
}
function secEvents(i, [key]) {
  const ev = store.get(i.guildId, 'security').events.filter((e) => e.rule === key).slice(-8).reverse();
  return page({ title: `📋 Ocorrências: ${security.RULES[key].name}`, text: ev.length ? ev.map((e) => `<@${e.userId}> • ${e.reason} • **${e.action}** • ${ts(e.at)}`).join('\n') : 'Nenhuma ocorrência registrada.', rows: [row(back(`cfg:sec:${key}`))] });
}

// ================= HONEYPOT =================
function honeypotPage(i) {
  const h = store.get(i.guildId, 'honeypot');
  return page({
    title: '🍯 Honeypot',
    text: [
      `**Status:** ${onoff(h.enabled)}`,
      `**Canal armadilha:** ${mention(h.channelId)}`,
      `**Canal do aviso:** ${mention(h.publishChannelId || h.channelId)} ${h.messageId ? '• aviso publicado ✅' : '• aviso não publicado'}`,
      `**Ação:** ${ACTION_LABEL[h.action]}${h.action === 'timeout' ? ` — ${h.days} dia(s)` : ''}`,
      `**Cargos isentos:** ${h.exemptRoles.map((x) => `<@&${x}>`).join(' ') || '—'}`,
      '',
      '-# Mensagens de membros no canal são apagadas e registradas (quem, quando, conteúdo). O canal precisa permitir que membros enviem mensagens, senão ninguém cai na armadilha.',
    ].join('\n'),
    rows: [
      row(btn('cfg:s_hp_toggle', h.enabled ? 'Desativar' : 'Ativar', { style: h.enabled ? 'danger' : 'success' }), btn('cfg:hp_days', 'Duração do timeout'), btn('tpl:main:honeypot.warn', '🎨 Aviso', { style: 'primary' }), btn('tpl:pub:honeypot.warn', 'Publicar aviso', { style: 'success' }), back('cfg:security', '← Segurança')),
      row(chanSel('cfg:s_hp_chan', 'Canal armadilha', TEXT, h.channelId ? [h.channelId] : [])),
      row(chanSel('cfg:s_hp_pub', 'Canal de publicação do aviso (opcional)', TEXT, h.publishChannelId ? [h.publishChannelId] : [])),
      row(strSel('cfg:s_hp_action', 'Ação ao detectar mensagem', Object.entries(honeypot.ACTIONS).map(([v, l]) => ({ label: l, value: v, default: h.action === v })))),
      row(roleSel('cfg:s_hp_roles', 'Cargos isentos', h.exemptRoles)),
    ],
  });
}

// ================= IA =================
function aiPage(i) {
  const d = store.get(i.guildId, 'ai');
  return page({
    title: '🤖 Inteligência artificial',
    text: `**Chave da API:** ${ai.hasKey() ? '✅ configurada nos Secrets' : '❌ ausente — defina ANTHROPIC_API_KEY (ou AI_API_KEY) na hospedagem'}\n\n` + Object.entries(ai.MODULES).map(([k, v]) => `**${v}:** ${ai.MODES[d.modes[k]]}`).join('\n') + `\n\n**Contexto do servidor:** ${d.context ? trunc(d.context, 200) : '*vazio*'}\n-# A IA nunca bane, expulsa ou aplica timeout. Em segurança, no máximo apaga a mensagem e avisa a equipe.`,
    rows: [
      ...Object.entries(ai.MODULES).map(([k, v]) => row(strSel(`cfg:s_ai_mode:${k}`, `${v}`, Object.entries(ai.MODES).map(([m, l]) => ({ label: l, value: m, default: d.modes[k] === m })))))
        .slice(0, 4),
      row(btn('cfg:ai_ctx', 'Contexto / FAQ', { style: 'primary' }), btn('cfg:ai_report', '📊 Gerar relatório'), back()),
    ],
  });
}

// ================= BOAS-VINDAS =================
function welcomePage(i, [which = 'join'] = []) {
  const w = store.get(i.guildId, 'welcome')[which];
  const ref = `welcome.${which}`;
  return page({
    title: `👋 ${which === 'join' ? 'Boas-vindas' : 'Saída de membros'}`,
    text: `**Status:** ${onoff(w.enabled)}\n**Canal:** ${mention(w.channelId)}${w.enabled && !w.channelId ? '\n⚠️ Escolha um canal para funcionar.' : ''}\nVariáveis: {user} {username} {server} {memberCount}`,
    rows: [
      row(btn('cfg:welcome:join', 'Entrada', { style: which === 'join' ? 'primary' : 'secondary' }), btn('cfg:welcome:leave', 'Saída', { style: which === 'leave' ? 'primary' : 'secondary' })),
      row(chanSel(`cfg:s_wel_chan:${which}`, 'Canal da mensagem', TEXT, w.channelId ? [w.channelId] : [])),
      row(btn(`cfg:s_wel_toggle:${which}`, w.enabled ? 'Desativar' : 'Ativar', { style: w.enabled ? 'danger' : 'success' }), btn(`tpl:main:${ref}`, '🎨 Aparência', { style: 'primary' }), btn(`tpl:prev:${ref}`, 'Prévia'), back()),
    ],
  });
}

// ================= AVISOS =================
function annPage(i, [sel] = []) {
  const d = store.get(i.guildId, 'announcements');
  const items = Object.values(d.items);
  const a = d.items[sel];
  return page({
    title: '📢 Avisos e anúncios',
    text: a ? `**${a.name}**\n**Canal:** ${mention(a.channelId)}\n**Publicado:** ${a.messageId ? `sim (${mention(a.messageChannelId)})` : 'não'}\n\nUse **Publicar** para enviar ou atualizar a mesma mensagem; **Excluir** remove a mensagem do canal.` : items.length ? 'Selecione um aviso ou crie um novo.' : 'Nenhum aviso. Crie o primeiro!',
    rows: [
      items.length ? row(strSel('cfg:ann_sel', 'Selecione um aviso', items.map((x) => ({ label: x.name, value: x.id, default: x.id === sel })))) : null,
      a ? row(chanSel(`cfg:s_ann_chan:${a.id}`, 'Canal de publicação', TEXT, a.channelId ? [a.channelId] : [])) : null,
      row(btn('cfg:ann_new', 'Novo', { style: 'success' }), btn(`tpl:main:ann.${sel}`, '🎨 Editar', { style: 'primary', disabled: !a }), btn(`tpl:pub:ann.${sel}`, 'Publicar', { style: 'success', disabled: !a }), btn(`cfg:s_ann_del:${sel}`, 'Excluir', { style: 'danger', disabled: !a }), back()),
    ],
  });
}

// ================= REGRAS =================
async function rulesPage(i) {
  const r = store.get(i.guildId, 'rules');
  return page({
    title: '📜 Regras do servidor',
    text: `**Canal:** ${mention(r.channelId)}\n**Publicado:** ${r.messageId ? 'sim' : 'não'}\n\nA mensagem publicada tem um botão **⚙️ Configurações** que abre este painel para administradores autorizados.`,
    rows: [
      row(chanSel('cfg:s_rules_chan', 'Canal das regras', TEXT, r.channelId ? [r.channelId] : [])),
      row(btn('tpl:main:rules.main', '🎨 Editar regras', { style: 'primary' }), btn('tpl:pub:rules.main', 'Publicar / atualizar', { style: 'success' }), btn('cfg:rules_ai', '🤖 Analisar com IA'), back()),
    ],
  });
}

// ================= BACKUP =================
function backupPage(i) {
  const list = store.listBackups().filter((s) => store.backupHasGuild(s, i.guildId));
  return page({
    title: '💾 Backup',
    text: `Os dados ficam em \`${store.DATA_DIR}\`. Backups automáticos rodam periodicamente; use um volume persistente na hospedagem.\n\n**Backups deste servidor:** ${list.length}\n${list.slice(0, 5).map((s) => `• \`${s}\``).join('\n')}`,
    rows: [
      list.length && i.user.id === OWNER_ID ? row(strSel('cfg:bk_sel', 'Restaurar a partir de… (só o proprietário)', list.slice(0, 25).map((s) => ({ label: s, value: s })))) : null,
      row(btn('cfg:s_bk_now', 'Criar backup agora', { style: 'success' }), back()),
    ],
  });
}

const PAGES = { general, tickets: ticketsPage, shop: shopPage, feedbacks: feedbacksPage, moderation: moderationPage, security: securityPage, honeypot: honeypotPage, ai: aiPage, welcome: welcomePage, ann: annPage, rules: rulesPage, backup: backupPage };

// ================= AÇÕES =================
const A = {
  home: (i) => home(i),
  nav: async (i) => {
    const v = i.values[0];
    if (!full(i) && v !== 'moderation') {
      await i.reply({ content: '❌ Sem permissão.', flags: ui.EPH });
      return null;
    }
    return PAGES[v](i, []);
  },
  // geral
  general: (i, a) => general(i, a),
  general_perm: (i) => general(i, [i.values[0]]),
  s_perm: (i, [perm]) => {
    if (perm === 'config' && i.user.id !== OWNER_ID) return { ...general(i, [perm]), _notice: '❌ Apenas o proprietário principal pode alterar o cargo `config`.' };
    store.update(i.guildId, 'core', (d) => {
      for (const r of Object.keys(d.permissions)) d.permissions[r] = d.permissions[r].filter((p) => p !== perm);
      for (const r of i.values) (d.permissions[r] ||= []).push(perm);
      for (const r of Object.keys(d.permissions)) if (!d.permissions[r].length) delete d.permissions[r];
    });
    return general(i, [perm]);
  },
  logs: (i, a) => logs(i, a),
  logs_kind: (i) => logs(i, [i.values[0]]),
  s_log: (i, [k]) => { store.update(i.guildId, 'core', (d) => { d.logs[k] = i.values[0]; }); return logs(i, [k]); },
  s_logclear: (i, [k]) => { store.update(i.guildId, 'core', (d) => { delete d.logs[k]; }); return logs(i, [k]); },
  // tickets
  tickets: (i) => ticketsPage(i),
  s_tk_toggle: (i) => { store.update(i.guildId, 'tickets', (d) => { d.settings.enabled = !d.settings.enabled; }); return ticketsPage(i); },
  s_tk_mode: (i) => { store.update(i.guildId, 'tickets', (d) => { d.settings.mode = d.settings.mode === 'thread' ? 'channel' : 'thread'; d.settings.destination = null; }); return ticketsPage(i); },
  s_tk_dest: (i) => { store.update(i.guildId, 'tickets', (d) => { d.settings.destination = i.values[0]; }); return ticketsPage(i); },
  tkcats: (i, a) => tkcats(i, a),
  tkcat_sel: (i) => tkcats(i, [i.values[0]]),
  tkcat_new: (i) => i.showModal(catModal('new')),
  tkcat_edit: (i, [id]) => i.showModal(catModal(id, store.get(i.guildId, 'tickets').categories[id])),
  s_tkcat_m: (i, [id]) => {
    const emoji = i.fields.getTextInputValue('emoji').trim();
    if (emoji && !require('./util').parseEmoji(emoji)) return { ...tkcats(i, id === 'new' ? [] : [id]), _notice: '❌ Emoji inválido (use um emoji normal ou <:nome:id>).' };
    const type = /^(loja|shop)$/i.test(i.fields.getTextInputValue('type').trim()) ? 'shop' : 'normal';
    let cid = id;
    store.update(i.guildId, 'tickets', (d) => {
      if (id === 'new') { cid = uid(6); d.categories[cid] = { id: cid, roleIds: [], questions: [] }; }
      Object.assign(d.categories[cid], { name: i.fields.getTextInputValue('name').trim(), emoji, description: i.fields.getTextInputValue('desc').trim(), type });
    });
    return tkcats(i, [cid]);
  },
  tkq: (i, [id]) => i.showModal(modal(`cfg:s_tkq:${id}`, 'Perguntas antes de abrir', [{ id: 'q', label: 'Uma pergunta por linha (máx. 5)', paragraph: true, required: false, max: 500, value: store.get(i.guildId, 'tickets').categories[id]?.questions.join('\n') }])),
  s_tkq: (i, [id]) => {
    const qs = i.fields.getTextInputValue('q').split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 5).map((x) => trunc(x, 45));
    store.update(i.guildId, 'tickets', (d) => { if (d.categories[id]) d.categories[id].questions = qs; });
    return tkcats(i, [id]);
  },
  s_tkcat_roles: (i, [id]) => { store.update(i.guildId, 'tickets', (d) => { if (d.categories[id]) d.categories[id].roleIds = i.values; }); return tkcats(i, [id]); },
  s_tkcat_del: (i, [id]) => {
    store.update(i.guildId, 'tickets', (d) => { delete d.categories[id]; for (const p of Object.values(d.panels)) p.categoryIds = p.categoryIds.filter((c) => c !== id); });
    return tkcats(i, []);
  },
  tkpanels: (i) => tkpanels(i),
  tkpanel_sel: (i) => tkpanel(i, [i.values[0]]),
  tkpanel: (i, a) => tkpanel(i, a),
  tkpanel_new: (i) => i.showModal(modal('cfg:s_tkpanel_new', 'Novo painel', [{ id: 'name', label: 'Nome do painel', max: 60 }])),
  s_tkpanel_new: (i) => {
    const id = uid(6);
    store.update(i.guildId, 'tickets', (d) => { d.panels[id] = { id, name: i.fields.getTextInputValue('name').trim(), channelId: null, messageId: null, messageChannelId: null, categoryIds: [], style: 'buttons' }; });
    return tkpanel(i, [id]);
  },
  s_tkpanel_chan: (i, [id]) => { store.update(i.guildId, 'tickets', (d) => { d.panels[id].channelId = i.values[0]; }); return tkpanel(i, [id]); },
  s_tkpanel_cats: (i, [id]) => { store.update(i.guildId, 'tickets', (d) => { d.panels[id].categoryIds = i.values; }); return tkpanel(i, [id]); },
  s_tkpanel_style: (i, [id]) => { store.update(i.guildId, 'tickets', (d) => { d.panels[id].style = d.panels[id].style === 'select' ? 'buttons' : 'select'; }); return tkpanel(i, [id]); },
  s_tkpanel_del: async (i, [id]) => {
    const p = store.get(i.guildId, 'tickets').panels[id];
    if (p?.messageId) { const ch = await i.guild.channels.fetch(p.messageChannelId).catch(() => null); await ch?.messages?.delete(p.messageId).catch(() => {}); }
    store.update(i.guildId, 'tickets', (d) => { delete d.panels[id]; });
    templates.remove(i.guildId, `ticket.panel.${id}`);
    return tkpanels(i);
  },
  // loja
  shop: (i, a) => shopPage(i, a),
  shop_sel: (i) => shopPage(i, [i.values[0]]),
  prod_new: (i) => i.showModal(prodModal('new')),
  prod_edit: (i, [id]) => i.showModal(prodModal(id, store.get(i.guildId, 'shop').products[id])),
  s_prod_m: (i, [id]) => {
    const price = parseFloat(i.fields.getTextInputValue('price').replace(/[^\d,.-]/g, '').replace(',', '.'));
    const image = i.fields.getTextInputValue('image').trim();
    if (!Number.isFinite(price) || price < 0) return { ...shopPage(i, id === 'new' ? [] : [id]), _notice: '❌ Preço inválido.' };
    if (image && !isUrl(image)) return { ...shopPage(i, id === 'new' ? [] : [id]), _notice: '❌ URL da imagem inválida.' };
    let pid = id;
    store.update(i.guildId, 'shop', (d) => {
      if (id === 'new') { pid = uid(6); d.products[pid] = { id: pid, roleIds: [], buttons: [], categoryId: null }; }
      Object.assign(d.products[pid], { name: i.fields.getTextInputValue('name').trim(), price: Math.round(price * 100) / 100, description: i.fields.getTextInputValue('desc').trim(), image });
    });
    return shopPage(i, [pid]);
  },
  prod_btns: (i, [id]) => i.showModal(modal(`cfg:s_prod_btns:${id}`, 'Botões do produto (links)', [{ id: 'b', label: 'Uma linha por botão: Texto|https://url (máx. 3)', paragraph: true, required: false, max: 600, value: (store.get(i.guildId, 'shop').products[id]?.buttons || []).map((b) => `${b.label}|${b.url}`).join('\n') }])),
  s_prod_btns: (i, [id]) => {
    const list = i.fields.getTextInputValue('b').split('\n').map((l) => l.split('|')).filter((p) => p.length >= 2 && isUrl(p.slice(1).join('|').trim())).slice(0, 3).map((p) => ({ label: trunc(p[0].trim() || 'Abrir', 80), url: p.slice(1).join('|').trim() }));
    store.update(i.guildId, 'shop', (d) => { if (d.products[id]) d.products[id].buttons = list; });
    return shopPage(i, [id]);
  },
  s_prod_roles: (i, [id]) => { store.update(i.guildId, 'shop', (d) => { if (d.products[id]) d.products[id].roleIds = i.values; }); return shopPage(i, [id]); },
  s_prod_cat: (i, [id]) => { store.update(i.guildId, 'shop', (d) => { if (d.products[id]) d.products[id].categoryId = i.values[0] === '__default' ? null : i.values[0]; }); return shopPage(i, [id]); },
  s_prod_del: (i, [id]) => { store.update(i.guildId, 'shop', (d) => { delete d.products[id]; }); return shopPage(i, []); },
  deliveries: (i) => deliveries(i),
  // feedbacks
  feedbacks: (i) => feedbacksPage(i),
  s_fb_chan: (i) => { store.update(i.guildId, 'feedback', (d) => { d.settings.channelId = i.values[0]; }); return feedbacksPage(i); },
  s_fb_toggle: (i) => { store.update(i.guildId, 'feedback', (d) => { d.settings.enabled = !d.settings.enabled; }); return feedbacksPage(i); },
  // moderação
  moderation: (i) => moderationPage(i),
  s_mod_dm: (i) => { store.update(i.guildId, 'moderation', (d) => { d.settings.dm = !d.settings.dm; }); return moderationPage(i); },
  mod_msgs: (i) => modMsgs(i),
  mod_msg_sel: (i) => i.showModal(modal(`cfg:s_mod_msg:${i.values[0]}`, `Mensagem: ${moderation.TYPES[i.values[0]]}`, [{ id: 't', label: 'Texto (vazio = padrão)', paragraph: true, required: false, max: 1500, value: store.get(i.guildId, 'moderation').settings.messages[i.values[0]] || moderation.DEFAULT_MSG[i.values[0]] }])),
  s_mod_msg: (i, [t]) => { const v = i.fields.getTextInputValue('t').trim(); store.update(i.guildId, 'moderation', (d) => { if (v) d.settings.messages[t] = v; else delete d.settings.messages[t]; }); return modMsgs(i); },
  mod_apply: (i) => modApply(i),
  mod_user: (i) => page({ title: '⚖️ Tipo de punição', text: `Alvo: <@${i.values[0]}>`, rows: [row(strSel(`cfg:mod_act:${i.values[0]}`, 'Escolha a punição', ['warn', 'timeout', 'kick', 'ban'].map((t) => ({ label: moderation.TYPES[t], value: t })))), row(back('cfg:mod_apply'))] }),
  mod_act: (i, [uidTarget]) => {
    const type = i.values[0];
    const f = [{ id: 'reason', label: 'Motivo', paragraph: true, max: 400 }];
    if (type === 'timeout') f.push({ id: 'min', label: 'Duração em minutos (máx. 40320)', max: 6, value: '60' });
    return i.showModal(modal(`cfg:s_mod_exec:${uidTarget}:${type}`, moderation.TYPES[type], f));
  },
  s_mod_exec: async (i, [target, type]) => {
    await i.deferUpdate();
    const min = type === 'timeout' ? int(i.fields.getTextInputValue('min'), 1, 40320, 60) : 0;
    const res = await moderation.apply(i.guild, { targetId: target, moderator: { id: i.user.id, member: i.member }, type, reason: i.fields.getTextInputValue('reason').trim(), durationMs: min * 60000, source: 'manual' });
    return { ...moderationPage(i), _notice: res.ok ? `✅ ${moderation.TYPES[type]} aplicada a <@${target}>.${res.dmSent === false ? ' (DM não entregue)' : ''}` : `❌ ${res.error}` };
  },
  mod_unban: async (i) => {
    const bans = await i.guild.bans.fetch({ limit: 25 }).catch(() => null);
    if (!bans?.size) return { ...moderationPage(i), _notice: '✅ Não há banimentos (ou o bot não pode ver a lista).' };
    return page({ title: '♻️ Remover banimento', text: 'Selecione quem terá o banimento removido:', rows: [row(strSel('cfg:mod_unban_sel', 'Usuário banido', [...bans.values()].map((b) => ({ label: b.user.username, value: b.user.id, description: trunc(b.reason || 'sem motivo', 100) })))), row(back('cfg:moderation'))] });
  },
  mod_unban_sel: (i) => i.showModal(modal(`cfg:s_unban:${i.values[0]}`, 'Remover banimento', [{ id: 'reason', label: 'Motivo', paragraph: true, max: 400 }])),
  s_unban: async (i, [target]) => {
    await i.deferUpdate();
    const res = await moderation.apply(i.guild, { targetId: target, moderator: { id: i.user.id, member: i.member }, type: 'unban', reason: i.fields.getTextInputValue('reason').trim(), source: 'manual' });
    return { ...moderationPage(i), _notice: res.ok ? `✅ Banimento de <@${target}> removido.` : `❌ ${res.error}` };
  },
  mod_clear: () => page({ title: '🧹 Limpar mensagens', text: 'Escolha o canal (mensagens com mais de 14 dias não podem ser apagadas em massa):', rows: [row(chanSel('cfg:mod_clear_ch', 'Canal', TEXT, [], { min: 1, max: 1 })), row(back('cfg:moderation'))] }),
  mod_clear_ch: (i) => i.showModal(modal(`cfg:s_clear:${i.values[0]}`, 'Limpar mensagens', [{ id: 'n', label: 'Quantidade (1 a 100)', max: 3, value: '10' }])),
  s_clear: async (i, [chId]) => {
    await i.deferUpdate();
    const ch = await i.guild.channels.fetch(chId).catch(() => null);
    if (!ch?.isTextBased()) return { ...moderationPage(i), _notice: '❌ Canal inválido.' };
    try {
      const n = await moderation.clearMessages(i.guild, ch, int(i.fields.getTextInputValue('n'), 1, 100, 10), i.user);
      return { ...moderationPage(i), _notice: `✅ ${n} mensagem(ns) apagada(s) em <#${chId}>.` };
    } catch (e) { return { ...moderationPage(i), _notice: `❌ ${e.message}` }; }
  },
  mod_hist: () => page({ title: '🗂️ Histórico de punições', text: 'Escolha o membro:', rows: [row(userSel('cfg:mod_hist_user', 'Selecione o membro')), row(back('cfg:moderation'))] }),
  mod_hist_user: (i) => {
    const h = moderation.history(i.guildId, i.values[0], 10);
    return page({ title: '🗂️ Histórico', text: `<@${i.values[0]}>\n\n${h.length ? h.map(moderation.line).join('\n') : '*Sem registros.*'}`, rows: [row(back('cfg:moderation'))] });
  },
  // segurança
  security: (i) => securityPage(i),
  sec_sel: (i) => (i.values[0] === '__hp' ? honeypotPage(i) : secRule(i, [i.values[0]])),
  sec: (i, a) => secRule(i, a),
  s_sec_toggle: (i, [k]) => { security.setRule(i.guildId, k, { enabled: !security.rule(i.guildId, k).enabled }); return secRule(i, [k]); },
  s_sec_action: (i, [k]) => { security.setRule(i.guildId, k, { action: i.values[0] }); return secRule(i, [k]); },
  s_sec_roles: (i, [k]) => { security.setRule(i.guildId, k, { exemptRoles: i.values }); return secRule(i, [k]); },
  s_sec_chans: (i, [k]) => { security.setRule(i.guildId, k, { exemptChannels: i.values }); return secRule(i, [k]); },
  s_sec_bots: (i) => { security.setRule(i.guildId, 'bot', { allowedBots: i.values }); return secRule(i, ['bot']); },
  s_sec_noavatar: (i) => { security.setRule(i.guildId, 'fake', { noAvatar: !security.rule(i.guildId, 'fake').noAvatar }); return secRule(i, ['fake']); },
  sec_lim: (i, [k]) => {
    const r = security.rule(i.guildId, k);
    return i.showModal(modal(`cfg:s_sec_lim:${k}`, `${security.RULES[k].name}: limites`, security.RULES[k].fields.map((f) => ({ id: f, label: security.FIELD_LABELS[f], max: 6, value: String(r[f]) }))));
  },
  s_sec_lim: (i, [k]) => {
    const r = security.rule(i.guildId, k);
    const lim = { limit: [1, 100], windowSec: [1, 3600], timeoutMin: [1, 40320], minAgeDays: [0, 3650] };
    const patch = {};
    for (const f of security.RULES[k].fields) patch[f] = int(i.fields.getTextInputValue(f), lim[f][0], lim[f][1], r[f]);
    security.setRule(i.guildId, k, patch);
    return secRule(i, [k]);
  },
  sec_adv: (i, [k]) => {
    const r = security.rule(i.guildId, k);
    const f = k === 'link' ? 'allowedDomains' : 'blockedDomains';
    return i.showModal(modal(`cfg:s_sec_adv:${k}`, k === 'link' ? 'Domínios permitidos' : 'Domínios bloqueados', [{ id: 'd', label: 'Um domínio por linha (ex.: youtube.com)', paragraph: true, required: false, max: 1500, value: r[f].join('\n') }]));
  },
  s_sec_adv: (i, [k]) => {
    const list = [...new Set(i.fields.getTextInputValue('d').split(/[\n,\s]+/).map((x) => x.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0]).filter(Boolean))].slice(0, 100);
    security.setRule(i.guildId, k, { [k === 'link' ? 'allowedDomains' : 'blockedDomains']: list });
    return secRule(i, [k]);
  },
  sec_events: (i, a) => secEvents(i, a),
  // honeypot
  honeypot: (i) => honeypotPage(i),
  s_hp_toggle: (i) => {
    const h = store.get(i.guildId, 'honeypot');
    if (!h.enabled && !h.channelId) return { ...honeypotPage(i), _notice: '❌ Escolha o canal armadilha antes de ativar.' };
    store.update(i.guildId, 'honeypot', (d) => { d.enabled = !d.enabled; });
    return honeypotPage(i);
  },
  s_hp_chan: (i) => { store.update(i.guildId, 'honeypot', (d) => { d.channelId = i.values[0]; d.messageId = null; }); return honeypotPage(i); },
  s_hp_pub: (i) => { store.update(i.guildId, 'honeypot', (d) => { d.publishChannelId = i.values[0]; d.messageId = null; }); return honeypotPage(i); },
  s_hp_action: (i) => { store.update(i.guildId, 'honeypot', (d) => { d.action = i.values[0]; }); return honeypotPage(i); },
  s_hp_roles: (i) => { store.update(i.guildId, 'honeypot', (d) => { d.exemptRoles = i.values; }); return honeypotPage(i); },
  hp_days: (i) => i.showModal(modal('cfg:s_hp_days', 'Duração do timeout', [{ id: 'd', label: 'Dias (1 a 28)', max: 2, value: String(store.get(i.guildId, 'honeypot').days) }])),
  s_hp_days: (i) => { const n = int(i.fields.getTextInputValue('d'), 1, 28, 7); store.update(i.guildId, 'honeypot', (d) => { d.days = n; }); return honeypotPage(i); },
  // IA
  ai: (i) => aiPage(i),
  s_ai_mode: (i, [k]) => { store.update(i.guildId, 'ai', (d) => { d.modes[k] = i.values[0]; }); return aiPage(i); },
  ai_ctx: (i) => i.showModal(modal('cfg:s_ai_ctx', 'Contexto do servidor para a IA', [{ id: 'c', label: 'FAQ, preços, regras de atendimento…', paragraph: true, required: false, max: 3000, value: store.get(i.guildId, 'ai').context }])),
  s_ai_ctx: (i) => { const c = i.fields.getTextInputValue('c').trim(); store.update(i.guildId, 'ai', (d) => { d.context = c; }); return aiPage(i); },
  ai_report: async (i) => {
    await i.deferReply({ flags: ui.EPH });
    try { await i.editReply({ content: trunc(await ai.report(i.guild), 1950) }); } catch (e) { await i.editReply({ content: `❌ ${e.message}` }); }
    return null;
  },
  rules_ai: async (i) => {
    await i.deferReply({ flags: ui.EPH });
    try {
      const t = templates.get(i.guildId, 'rules.main');
      const text = [t.title, t.description, ...t.sections.map((s) => `${s.title}\n${s.text}`)].join('\n\n');
      await i.editReply({ content: trunc(`🤖 **Análise das regras**\n${await ai.analyzeRules(i.guild, text)}`, 1950) });
    } catch (e) { await i.editReply({ content: `❌ ${e.message}` }); }
    return null;
  },
  // boas-vindas
  welcome: (i, a) => welcomePage(i, a),
  s_wel_chan: (i, [w]) => { store.update(i.guildId, 'welcome', (d) => { d[w].channelId = i.values[0]; }); return welcomePage(i, [w]); },
  s_wel_toggle: (i, [w]) => {
    if (!store.get(i.guildId, 'welcome')[w].enabled && !store.get(i.guildId, 'welcome')[w].channelId) return { ...welcomePage(i, [w]), _notice: '❌ Escolha um canal antes de ativar.' };
    store.update(i.guildId, 'welcome', (d) => { d[w].enabled = !d[w].enabled; });
    return welcomePage(i, [w]);
  },
  // avisos
  ann: (i, a) => annPage(i, a),
  ann_sel: (i) => annPage(i, [i.values[0]]),
  ann_new: (i) => i.showModal(modal('cfg:s_ann_new', 'Novo aviso', [{ id: 'name', label: 'Nome interno do aviso', max: 60 }])),
  s_ann_new: (i) => {
    const id = uid(6);
    store.update(i.guildId, 'announcements', (d) => { d.items[id] = { id, name: i.fields.getTextInputValue('name').trim(), channelId: null, messageId: null, messageChannelId: null }; });
    return annPage(i, [id]);
  },
  s_ann_chan: (i, [id]) => { store.update(i.guildId, 'announcements', (d) => { d.items[id].channelId = i.values[0]; d.items[id].messageId = null; }); return annPage(i, [id]); },
  s_ann_del: async (i, [id]) => { await announcements.remove(i.guild, id); return annPage(i, []); },
  // regras
  rules: (i) => rulesPage(i),
  s_rules_chan: (i) => { store.update(i.guildId, 'rules', (d) => { d.channelId = i.values[0]; d.messageId = null; }); return rulesPage(i); },
  // backup
  backup: (i) => backupPage(i),
  s_bk_now: (i) => { const s = store.backupNow(); return { ...backupPage(i), _notice: `✅ Backup criado: \`${s}\`` }; },
  bk_sel: (i) => page({ title: '⚠️ Restaurar backup', text: `Restaurar \`${i.values[0]}\` substitui os dados atuais deste servidor (um backup de segurança é criado antes).`, rows: [row(btn(`cfg:s_bk_restore:${i.values[0]}`, 'Confirmar restauração', { style: 'danger' }), back('cfg:backup', 'Cancelar'))] }),
  s_bk_restore: (i, [stamp]) => {
    if (i.user.id !== OWNER_ID) return { ...backupPage(i), _notice: '❌ Só o proprietário principal restaura backups.' };
    try { store.restoreGuild(stamp, i.guildId); return { ...backupPage(i), _notice: '✅ Backup restaurado.' }; } catch (e) { return { ...backupPage(i), _notice: `❌ ${e.message}` }; }
  },
};

const MOD_ACTS = new Set(['moderation', 'mod_apply', 'mod_user', 'mod_act', 's_mod_exec', 'mod_unban', 'mod_unban_sel', 's_unban', 'mod_clear', 'mod_clear_ch', 's_clear', 'mod_hist', 'mod_hist_user', 'home', 'nav']);

async function open(i) {
  if (!i.guild) return i.reply({ content: 'Use este comando dentro de um servidor.', flags: ui.EPH });
  if (!full(i) && !canMod(i)) return i.reply({ content: '❌ Você não tem permissão para usar o /config.', flags: ui.EPH });
  return i.reply(ui.ephemeral(home(i)));
}

async function handle(i) {
  const [, act, ...args] = i.customId.split(':');
  if (!i.guild) return;
  const allowed = full(i) || (canMod(i) && MOD_ACTS.has(act));
  if (!allowed) return i.reply({ content: '❌ Você não tem permissão para esta ação.', flags: ui.EPH });
  const fn = A[act];
  if (!fn) return i.reply({ content: '❌ Ação desconhecida.', flags: ui.EPH });
  let out = await fn(i, args);
  if (!out || out === true || i.replied) return;
  const notice = out._notice;
  if (notice) { out = { ...out }; delete out._notice; }
  if (i.deferred) await i.editReply(out);
  else await i.update(out);
  if (notice) await i.followUp({ content: notice, flags: ui.EPH });
  if (act.startsWith('s_') && !notice?.startsWith('❌')) {
    await log(i.guild, 'admin', { title: 'Configuração alterada', description: `<@${i.user.id}> • \`${act}\`${args.length ? ` (${args.join(', ')})` : ''}${i.values ? ` → ${trunc(i.values.join(', '), 200)}` : ''}` });
  }
}

module.exports = { open, handle, rulesPage };
