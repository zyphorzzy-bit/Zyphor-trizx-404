module.exports = {
  OWNER_ID: process.env.OWNER_ID || '1533306874513068093',
  COLORS: { brand: 0x5865f2, ok: 0x57f287, warn: 0xfee75c, err: 0xed4245 },
  PERMS: {
    config: 'Acesso total ao /config',
    moderation: 'Moderação (punições pelo /config)',
    tickets: 'Atender tickets (todas as categorias)',
    feedbacks: 'Consultar feedbacks (z!feedbacks)',
    deliver: 'Entregar compras',
  },
  LOG_KINDS: {
    tickets: 'Tickets (criados/fechados)',
    transcripts: 'Transcrições',
    feedbacks: 'Feedbacks',
    shop: 'Produtos, compras e entregas',
    moderation: 'Moderação',
    security: 'Segurança',
    honeypot: 'Honeypot',
    admin: 'Alterações administrativas',
  },
};
