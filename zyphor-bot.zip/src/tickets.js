const { ChannelType, PermissionFlagsBits: P, AttachmentBuilder } = require('discord.js');
const store = require('./storage');
const templates = require('./templates');
const ui = require('./ui');
const feedback = require('./feedback');
const { hasPerm, rolesWithPerm } = require('./permissions');
const { log } = require('./logs');
const { OWNER_ID } = require('./constants');
const { trunc, BRL, ts } = require('./util');

const creating = new Set();
const STAFF_ALLOW = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks];

// ---------- helpers ----------
function staffRoleIds(gid, cat) {
  return [...new Set([...(cat?.roleIds || []), ...rolesWithPerm(gid, 'tickets'), ...rolesWithPerm(gid, 'config')])];
}
function isStaff(gid, member, userId, ticket) {
  if (userId === OWNER_ID) return true;
  if (!member) return false;
  const cat = store.get(gid, 'tickets').categories[ticket.categoryId];
  return staffRoleIds(gid, cat).some((r) => member.roles.cache.has(r));
}
function canControl(gid, member, userId, ticket) {
  if (!isStaff(gid, member, userId, ticket)) return false;
  return !ticket.claimedBy || ticket.claimedBy === userId || hasPerm(gid, member, userId, 'config');
}
const getTicket = (gid, channelId) => store.get(gid, 'tickets').open[channelId];

// ---------- painel de abertura ----------
async function publishPanel(i, ref) {
  const panelId = ref.split('.')[2];
  const d = store.get(i.guildId, 'tickets');
  const panel = d.panels[panelId];
  if (!panel) throw new Error('Painel não encontrado.');
  if (!panel.channelId) throw new Error('Escolha o canal de publicação do painel.');
  const cats = panel.categoryIds.map((id) => d.categories[id]).filter(Boolean);
  if (!cats.length) throw new Error('Selecione ao menos uma categoria para o painel.');
  const ch = await i.guild.channels.fetch(panel.channelId).catch(() => null);
  if (!ch?.isTextBased()) throw new Error('Canal inválido.');
  let rows;
  if (panel.style === 'select') {
    rows = [ui.row(ui.strSel(`tk:sel:${panelId}`, 'Selecione o tipo de atendimento', cats.map((c) => ({ label: c.name, value: c.id, description: c.description, emoji: c.emoji }))))];
  } else {
    rows = [];
    for (let k = 0; k < cats.length; k += 5) rows.push(ui.row(cats.slice(k, k + 5).map((c) => ui.btn(`tk:open:${c.id}`, c.name, { style: 'primary', emoji: c.emoji }))));
  }
  const payload = { ...ui.renderTemplate(templates.get(i.guildId, ref), templates.varsFor(i.user, i.guild), ref, rows), allowedMentions: { parse: [] } };
  let msg = null;
  if (panel.messageId && panel.messageChannelId === ch.id) msg = await ch.messages.fetch(panel.messageId).catch(() => null);
  if (msg) await msg.edit(payload);
  else msg = await ch.send(payload);
  store.update(i.guildId, 'tickets', (x) => {
    x.panels[panelId].messageId = msg.id;
    x.panels[panelId].messageChannelId = ch.id;
  });
  return `✅ Painel publicado em <#${ch.id}>.`;
}
templates.registerKind('ticket.panel', { back: (ref) => `cfg:tkpanel:${ref.split('.')[2]}`, publish: publishPanel, publishLabel: 'Publicar painel' });

// ---------- mensagem de controle do ticket ----------
function ticketPayload(guild, t) {
  const d = store.get(guild.id, 'tickets');
  const cat = d.categories[t.categoryId];
  const prod = t.productId ? store.get(guild.id, 'shop').products[t.productId] : null;
  const ai = require('./ai');
  const status = t.claimedBy ? `🟢 Em atendimento por <@${t.claimedBy}>` : '🟡 Aguardando um atendente';
  const lines = [
    `**Cliente:** <@${t.userId}>`,
    `**Categoria:** ${cat?.emoji || ''} ${t.categoryName}`,
    prod ? `**Produto:** ${prod.name} — ${BRL(prod.price)}` : t.productName ? `**Produto:** ${t.productName}` : null,
    t.subject ? `**Assunto:** ${t.subject}` : null,
    `**Status:** ${t.onHold ? '⏸️ Em espera • ' : ''}${status}`,
    t.participants.length ? `**Participantes:** ${t.participants.map((u) => `<@${u}>`).join(' ')}` : null,
    t.delivered ? `**Entrega:** ✅ concluída` : null,
    t.notes ? `**Notas da equipe:** ${trunc(t.notes, 300)}` : null,
    ...t.answers.map((a) => `\n**${trunc(a.q, 100)}**\n${trunc(a.a, 500)}`),
  ].filter((x) => x !== null);
  const r1 = ui.row(
    ui.btn('tk:claim', 'Assumir', { style: 'success', disabled: !!t.claimedBy }),
    ui.btn('tk:add', 'Adicionar'),
    ui.btn('tk:edit', 'Editar'),
    ui.btn('tk:hold', t.onHold ? 'Retomar' : 'Espera', { style: 'primary' }),
    ui.btn('tk:close', 'Fechar', { style: 'danger' }),
  );
  const extra = [];
  if (t.productId) extra.push(ui.btn('tk:deliver', 'Entregar compra', { style: 'success', disabled: !!t.delivered }));
  if (ai.mode(guild.id, 'tickets') !== 'off') extra.push(ui.btn('ai:suggest', '🤖 Sugestão IA'), ui.btn('ai:summary', '🤖 Resumo IA'));
  return { ...ui.page({ title: `🎫 Ticket #${String(t.number).padStart(4, '0')}`, text: lines.join('\n'), rows: [r1, extra.length ? ui.row(extra) : null], color: t.onHold ? ui.COLORS.warn : t.claimedBy ? ui.COLORS.ok : ui.COLORS.brand }), allowedMentions: { parse: [] } };
}
async function refresh(channel, t) {
  const msg = await channel.messages.fetch(t.messageId).catch(() => null);
  if (msg) await msg.edit(ticketPayload(channel.guild, t)).catch(() => {});
}

// ---------- abertura ----------
async function startOpen(i, catId) {
  const gid = i.guildId;
  const d = store.get(gid, 'tickets');
  const cat = d.categories[catId];
  if (!cat) return i.reply({ content: '❌ Esta categoria não existe mais.', flags: ui.EPH });
  if (!d.settings.enabled) return i.reply({ content: '❌ O sistema de tickets está desativado.', flags: ui.EPH });
  const existing = Object.values(d.open).find((t) => t.userId === i.user.id);
  if (existing || creating.has(i.user.id)) return i.reply({ content: `❌ Você já tem um ticket aberto${existing ? `: <#${existing.channelId}>` : '.'}`, flags: ui.EPH });
  if (cat.type === 'shop') {
    const products = Object.values(store.get(gid, 'shop').products);
    if (!products.length) return i.reply({ content: '❌ Nenhum produto cadastrado no momento.', flags: ui.EPH });
    return i.reply(ui.ephemeral(ui.page({
      title: '🛒 Escolha um produto',
      text: 'Selecione o produto para ver os detalhes. O ticket só é aberto quando você clicar em **Comprar**.',
      rows: [ui.row(ui.strSel(`tk:prod:${catId}`, 'Selecione um produto', products.map((p) => ({ label: p.name, value: p.id, description: BRL(p.price) }))))],
    })));
  }
  if (cat.questions?.length) {
    return i.showModal(ui.modal(`tk:modal:${catId}`, trunc(cat.name, 45), cat.questions.slice(0, 5).map((q, k) => ({ id: `q${k}`, label: trunc(q, 45), paragraph: true, max: 1000 }))));
  }
  await i.deferReply({ flags: ui.EPH });
  return createTicket(i, cat, null, []);
}

async function createTicket(i, cat, product, answers, v2 = false) {
  const respond = (text) => (v2 ? i.editReply(ui.page({ title: '🎫 Ticket', text })) : i.editReply({ content: text, components: [] }));
  const guild = i.guild;
  const gid = guild.id;
  const d0 = store.get(gid, 'tickets');
  if (Object.values(d0.open).find((t) => t.userId === i.user.id) || creating.has(i.user.id)) return respond('❌ Você já tem um ticket aberto.');
  creating.add(i.user.id);
  try {
    const { mode, destination } = d0.settings;
    const me = guild.members.me;
    const staffIds = staffRoleIds(gid, cat).filter((r) => guild.roles.cache.has(r));
    const number = store.update(gid, 'tickets', (d) => { d.counter++; }).counter;
    const name = `ticket-${String(number).padStart(4, '0')}`;
    let channel;
    if (mode === 'thread') {
      const parent = destination ? await guild.channels.fetch(destination).catch(() => null) : null;
      if (!parent || parent.type !== ChannelType.GuildText) return respond('❌ Canal de tópicos não configurado. Avise a equipe.');
      channel = await parent.threads.create({ name, type: ChannelType.PrivateThread, invitable: false, autoArchiveDuration: 10080, reason: `Ticket de ${i.user.tag}` });
      await channel.members.add(i.user.id);
    } else {
      const parent = destination ? await guild.channels.fetch(destination).catch(() => null) : null;
      const overwrites = [
        { id: guild.id, deny: [P.ViewChannel] },
        { id: i.user.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks], deny: [P.CreatePublicThreads, P.CreatePrivateThreads, P.ManageChannels, P.ManageRoles] },
        { id: me.id, allow: [...STAFF_ALLOW, P.ManageChannels, P.ManageMessages] },
        ...staffIds.map((id) => ({ id, allow: STAFF_ALLOW })),
      ];
      channel = await guild.channels.create({ name, type: ChannelType.GuildText, parent: parent?.type === ChannelType.GuildCategory ? parent.id : undefined, permissionOverwrites: overwrites, topic: `Ticket #${number} • ${i.user.tag} • ${cat.name}`, reason: `Ticket de ${i.user.tag}` });
    }
    const ticket = {
      number, channelId: channel.id, mode, userId: i.user.id, categoryId: cat.id, categoryName: cat.name,
      productId: product?.id || null, productName: product?.name || null, productPrice: product?.price ?? null,
      claimedBy: null, onHold: false, participants: [], answers, subject: null, notes: null, createdAt: Date.now(), messageId: null, delivered: false,
    };
    await channel.send({ content: `<@${i.user.id}> ${staffIds.map((r) => `<@&${r}>`).join(' ')}`.trim(), allowedMentions: { users: [i.user.id], roles: staffIds } });
    const msg = await channel.send(ticketPayload(guild, ticket));
    ticket.messageId = msg.id;
    store.update(gid, 'tickets', (d) => { d.open[channel.id] = ticket; });
    await log(guild, 'tickets', { title: `Ticket #${number} criado`, description: `**Cliente:** <@${i.user.id}>\n**Categoria:** ${cat.name}${product ? `\n**Produto:** ${product.name} (${BRL(product.price)})` : ''}\n**Canal:** <#${channel.id}>` });
    if (product) await log(guild, 'shop', { title: 'Compra iniciada', description: `<@${i.user.id}> iniciou a compra de **${product.name}** (${BRL(product.price)}) — ticket #${number}. Pagamento ainda **não confirmado**.` });
    return respond(`✅ Ticket criado: <#${channel.id}>`);
  } catch (e) {
    console.error('[tickets] criar:', e);
    return respond(`❌ Não consegui criar o ticket: ${e.message}`);
  } finally {
    creating.delete(i.user.id);
  }
}

// ---------- transcrição ----------
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
async function fetchAll(channel) {
  const out = [];
  let before;
  for (let k = 0; k < 100; k++) {
    const batch = await channel.messages.fetch({ limit: 100, before });
    if (!batch.size) break;
    out.push(...batch.values());
    before = batch.last().id;
  }
  return out.reverse();
}
function transcriptHtml(t, msgs, guild) {
  const rows = msgs.map((m) => {
    const att = [...m.attachments.values()].map((a) => `<div>📎 <a href="${esc(a.url)}">${esc(a.name)}</a></div>`).join('');
    const emb = m.embeds.map((e) => `<div class="e">${esc(e.title || '')} ${esc(e.description || '')}</div>`).join('');
    const v2 = m.components?.length && !m.content ? '<div class="e">[painel de componentes]</div>' : '';
    return `<div class="m"><b>${esc(m.author.tag)}</b> <span>${m.createdAt.toISOString()}</span><div>${esc(m.content)}</div>${att}${emb}${v2}</div>`;
  });
  return `<!doctype html><meta charset="utf-8"><title>Ticket #${t.number}</title><style>body{font-family:sans-serif;background:#1e1f22;color:#dbdee1;padding:20px}.m{margin:10px 0;padding:8px;background:#2b2d31;border-radius:6px}span{color:#949ba4;font-size:12px}.e{border-left:3px solid #5865f2;padding-left:8px;margin-top:4px}a{color:#00a8fc}</style><h2>${esc(guild.name)} — Ticket #${t.number}</h2><p>Categoria: ${esc(t.categoryName)} • Cliente: ${esc(t.userId)} • Aberto: ${new Date(t.createdAt).toISOString()}${t.productName ? ` • Produto: ${esc(t.productName)}` : ''}</p>${rows.join('')}`;
}

async function closeTicket(i, t, reason) {
  await i.deferReply({ flags: ui.EPH });
  const guild = i.guild;
  const ch = i.channel;
  let msgs = [];
  try { msgs = await fetchAll(ch); } catch (e) { console.error('[tickets] transcrição:', e.message); }
  const html = transcriptHtml(t, msgs, guild);
  const rel = `transcripts/${t.number}.html`;
  try { store.writeFile(guild.id, rel, html); } catch (e) { console.error('[tickets] salvar transcrição:', e.message); }
  const rec = { ...t, closedBy: i.user.id, closedAt: Date.now(), closeReason: reason || null, messages: msgs.length, transcript: rel };
  store.update(guild.id, 'tickets', (d) => { delete d.open[t.channelId]; d.closed[t.number] = rec; });
  const file = () => new AttachmentBuilder(Buffer.from(html), { name: `ticket-${String(t.number).padStart(4, '0')}.html` });
  await log(guild, 'transcripts', { title: `Transcrição — ticket #${t.number}`, description: `**Cliente:** <@${t.userId}>\n**Mensagens:** ${msgs.length}`, files: [file()] });
  await log(guild, 'tickets', { title: `Ticket #${t.number} fechado`, description: `**Fechado por:** <@${i.user.id}>\n**Cliente:** <@${t.userId}>\n**Atendente:** ${t.claimedBy ? `<@${t.claimedBy}>` : '—'}\n**Motivo:** ${reason || '—'}\n**Duração:** ${ts(t.createdAt)} → ${ts(rec.closedAt)}` });
  await i.editReply({ content: '✅ Ticket encerrado. Este canal será excluído agora.' }).catch(() => {});
  const deleted = await ch.delete(`Ticket #${t.number} fechado por ${i.user.tag}`).then(() => true).catch(() => false);
  if (!deleted) await log(guild, 'tickets', { title: 'Falha ao excluir canal', description: `Não consegui excluir <#${ch.id}> (ticket #${t.number}). Exclua manualmente.` });
  const user = await i.client.users.fetch(t.userId).catch(() => null);
  if (user) await feedback.sendRequest(guild, user, rec);
}

// ---------- entrega de compra ----------
async function deliver(i, t) {
  const guild = i.guild;
  const product = store.get(guild.id, 'shop').products[t.productId];
  if (!product) return i.update({ content: '❌ O produto deste ticket foi removido.', components: [] });
  const member = await guild.members.fetch(t.userId).catch(() => null);
  if (!member) return i.update({ content: '❌ O cliente não está mais no servidor.', components: [] });
  const me = guild.members.me;
  const results = [];
  if (!product.roleIds.length) results.push('ℹ️ Produto sem cargos — entrega manual registrada.');
  else if (!me.permissions.has(P.ManageRoles)) results.push('❌ O bot não tem a permissão **Gerenciar Cargos**.');
  else {
    for (const rid of product.roleIds) {
      const role = guild.roles.cache.get(rid);
      if (!role) results.push(`❌ Cargo ${rid} não existe mais.`);
      else if (role.managed) results.push(`❌ **${role.name}** é gerenciado por integração.`);
      else if (role.position >= me.roles.highest.position) results.push(`❌ **${role.name}** está acima do cargo do bot (hierarquia).`);
      else {
        try { await member.roles.add(role, `Entrega do ticket #${t.number} por ${i.user.tag}`); results.push(`✅ **${role.name}** entregue.`); }
        catch (e) { results.push(`❌ **${role.name}**: ${e.message}`); }
      }
    }
  }
  const failed = results.some((r) => r.startsWith('❌'));
  const delivery = { ticket: t.number, userId: t.userId, productId: product.id, productName: product.name, price: product.price, roleIds: product.roleIds, by: i.user.id, at: Date.now(), complete: !failed, results };
  store.update(guild.id, 'shop', (d) => { d.deliveries.push(delivery); });
  if (!failed) store.update(guild.id, 'tickets', (d) => { if (d.open[t.channelId]) d.open[t.channelId].delivered = true; });
  await log(guild, 'shop', { title: failed ? 'Entrega com falhas' : 'Entrega concluída', description: `**Produto:** ${product.name} (${BRL(product.price)})\n**Cliente:** <@${t.userId}>\n**Entregue por:** <@${i.user.id}> • ticket #${t.number}\n${results.join('\n')}` });
  await i.update({ content: results.join('\n') + (failed ? '\n\n⚠️ Corrija o problema e tente novamente.' : '\n\n🎉 Entrega registrada.'), components: [] });
  const fresh = getTicket(guild.id, t.channelId);
  if (fresh) await refresh(i.channel, fresh);
  if (!failed) await i.channel.send({ content: `📦 Compra de **${product.name}** entregue a <@${t.userId}> por <@${i.user.id}>.`, allowedMentions: { users: [t.userId] } }).catch(() => {});
}

// ---------- roteador ----------
async function handle(i) {
  const [, act, a, b] = i.customId.split(':');
  const gid = i.guildId;
  if (!i.guild) return;

  if (act === 'open') return startOpen(i, a);
  if (act === 'sel') return startOpen(i, i.values[0]);
  if (act === 'modal') {
    const cat = store.get(gid, 'tickets').categories[a];
    if (!cat) return i.reply({ content: '❌ Categoria removida.', flags: ui.EPH });
    await i.deferReply({ flags: ui.EPH });
    const answers = (cat.questions || []).map((q, k) => ({ q, a: i.fields.getTextInputValue(`q${k}`) }));
    return createTicket(i, cat, null, answers);
  }
  if (act === 'prod') {
    const p = store.get(gid, 'shop').products[i.values[0]];
    if (!p) return i.update(ui.page({ title: 'Produto', text: '❌ Produto indisponível.' }));
    const rows = [ui.row(ui.btn(`tk:buy:${a}:${p.id}`, 'Comprar', { style: 'success', emoji: '🛒' }), ...(p.buttons || []).slice(0, 3).map((x) => ui.linkBtn(x.url, x.label)))];
    const back = ui.strSel(`tk:prod:${a}`, 'Ver outro produto', Object.values(store.get(gid, 'shop').products).map((x) => ({ label: x.name, value: x.id, description: BRL(x.price), default: x.id === p.id })));
    const text = `${p.description || ''}\n\n**Preço:** ${BRL(p.price)}\n-# O pagamento é combinado e confirmado pela equipe dentro do ticket.`;
    const base = ui.page({ title: p.name, text, rows: [...rows, ui.row(back)], color: ui.COLORS.ok });
    if (p.image) {
      const { MediaGalleryBuilder, MediaGalleryItemBuilder } = require('discord.js');
      base.components[0].addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(p.image)));
    }
    return i.update(base);
  }
  if (act === 'buy') {
    const d = store.get(gid, 'tickets');
    const p = store.get(gid, 'shop').products[b];
    if (!p) return i.update(ui.page({ title: 'Produto', text: '❌ Produto indisponível.' }));
    let cat = d.categories[a];
    if (p.categoryId && d.categories[p.categoryId]) cat = d.categories[p.categoryId];
    if (!cat) return i.update(ui.page({ title: 'Ticket', text: '❌ Categoria removida.' }));
    if (Object.values(d.open).find((t) => t.userId === i.user.id)) return i.update(ui.page({ title: 'Ticket', text: '❌ Você já tem um ticket aberto.' }));
    await i.update(ui.page({ title: 'Ticket', text: '⏳ Abrindo seu ticket…' }));
    return createTicket(i, cat, p, [], true);
  }

  // ações dentro do ticket
  const t = getTicket(gid, i.channelId);
  if (!t) return i.reply({ content: '❌ Este não é um ticket ativo.', flags: ui.EPH });
  const staff = isStaff(gid, i.member, i.user.id, t);
  const deny = (msg) => i.reply({ content: `❌ ${msg}`, flags: ui.EPH });
  if (!staff) return deny('Apenas a equipe autorizada pode usar estes controles.');
  const controls = canControl(gid, i.member, i.user.id, t);
  const needControl = () => deny(`Este atendimento foi assumido por <@${t.claimedBy}>.`);

  switch (act) {
    case 'claim': {
      if (t.claimedBy) return deny(`Já assumido por <@${t.claimedBy}>.`);
      t.claimedBy = i.user.id;
      store.save(gid, 'tickets');
      await i.update(ticketPayload(i.guild, t));
      await i.channel.send({ content: `🙋 <@${i.user.id}> assumiu este atendimento.`, allowedMentions: { parse: [] } });
      return log(i.guild, 'tickets', { title: `Ticket #${t.number} assumido`, description: `<@${i.user.id}> assumiu o atendimento de <@${t.userId}>.` });
    }
    case 'hold': {
      if (!controls) return needControl();
      t.onHold = !t.onHold;
      store.save(gid, 'tickets');
      await i.update(ticketPayload(i.guild, t));
      return i.channel.send({ content: t.onHold ? `⏸️ Atendimento colocado em espera por <@${i.user.id}>.` : `▶️ Atendimento retomado por <@${i.user.id}>.`, allowedMentions: { parse: [] } });
    }
    case 'add': {
      if (!controls) return needControl();
      return i.reply({ content: 'Selecione quem deve ser adicionado ao ticket:', components: [ui.row(ui.userSel('tk:addsel', 'Selecionar participantes', { min: 1, max: 5 }))], flags: ui.EPH });
    }
    case 'addsel': {
      if (!controls) return needControl();
      const added = [];
      for (const id of i.values) {
        if (id === t.userId || t.participants.includes(id)) continue;
        try {
          if (t.mode === 'thread') await i.channel.members.add(id);
          else await i.channel.permissionOverwrites.edit(id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true });
          t.participants.push(id);
          added.push(id);
        } catch (e) { console.error('[tickets] adicionar:', e.message); }
      }
      store.save(gid, 'tickets');
      await i.update({ content: added.length ? `✅ Adicionado(s): ${added.map((u) => `<@${u}>`).join(' ')}` : '⚠️ Ninguém novo foi adicionado.', components: [] });
      await refresh(i.channel, t);
      if (added.length) await log(i.guild, 'tickets', { title: `Participantes adicionados ao ticket #${t.number}`, description: `Por <@${i.user.id}>: ${added.map((u) => `<@${u}>`).join(' ')}` });
      return;
    }
    case 'edit': {
      if (!controls) return needControl();
      return i.showModal(ui.modal('tk:editm', 'Editar ticket', [
        { id: 'subject', label: 'Assunto', required: false, max: 100, value: t.subject },
        { id: 'notes', label: 'Notas da equipe', paragraph: true, required: false, max: 500, value: t.notes },
      ]));
    }
    case 'editm': {
      if (!controls) return needControl();
      t.subject = i.fields.getTextInputValue('subject').trim() || null;
      t.notes = i.fields.getTextInputValue('notes').trim() || null;
      store.save(gid, 'tickets');
      return i.update(ticketPayload(i.guild, t));
    }
    case 'close': {
      if (!controls) return needControl();
      return i.showModal(ui.modal('tk:closem', `Fechar ticket #${t.number}`, [{ id: 'reason', label: 'Motivo (opcional) — ação definitiva', paragraph: true, required: false, max: 500 }]));
    }
    case 'closem': {
      if (!controls) return needControl();
      return closeTicket(i, t, i.fields.getTextInputValue('reason').trim());
    }
    case 'deliver': {
      if (!controls) return needControl();
      if (!t.productId) return deny('Este ticket não tem produto.');
      return i.reply({ content: `Confirma que o **pagamento de ${t.productName}** foi recebido e verificado? O bot vai entregar os cargos configurados.`, components: [ui.row(ui.btn('tk:deliverok', 'Confirmar e entregar', { style: 'success' }))], flags: ui.EPH });
    }
    case 'deliverok': {
      if (!controls) return needControl();
      return deliver(i, t);
    }
  }
}

// Canal/tópico apagado manualmente: não deixa ticket "preso" aberto
async function onChannelDelete(ch) {
  if (!ch.guild) return;
  const t = store.get(ch.guild.id, 'tickets').open[ch.id];
  if (!t) return;
  store.update(ch.guild.id, 'tickets', (d) => {
    delete d.open[ch.id];
    d.closed[t.number] = { ...t, closedBy: null, closedAt: Date.now(), closeReason: 'canal excluído manualmente', transcript: null };
  });
  await log(ch.guild, 'tickets', { title: `Ticket #${t.number} removido`, description: 'O canal foi excluído manualmente (sem transcrição).' });
}

module.exports = { handle, onChannelDelete, getTicket, isStaff };
