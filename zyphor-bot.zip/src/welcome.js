const store = require('./storage');
const templates = require('./templates');
const ui = require('./ui');

templates.registerKind('welcome', { back: (ref) => `cfg:welcome:${ref.split('.')[1]}` });

async function send(member, which) {
  const cfg = store.get(member.guild.id, 'welcome')[which];
  if (!cfg?.enabled || !cfg.channelId) return;
  const ch = await member.guild.channels.fetch(cfg.channelId).catch(() => null);
  if (!ch?.isTextBased()) return;
  const ref = `welcome.${which}`;
  const tpl = templates.get(member.guild.id, ref);
  const payload = ui.renderTemplate(tpl, templates.varsFor(member.user, member.guild), ref);
  // Em Embed a menção dentro do embed não notifica: manda a menção real no content.
  if (tpl.format === 'embed' && which === 'join') payload.content = `<@${member.id}>`;
  payload.allowedMentions = { users: which === 'join' ? [member.id] : [] };
  await ch.send(payload).catch((e) => console.error('[welcome]', e.message));
}

module.exports = { onJoin: (m) => send(m, 'join'), onLeave: (m) => send(m, 'leave') };
