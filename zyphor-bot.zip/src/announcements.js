const store = require('./storage');
const templates = require('./templates');
const ui = require('./ui');

async function publish(i, ref) {
  const id = ref.split('.')[1];
  const a = store.get(i.guildId, 'announcements').items[id];
  if (!a) throw new Error('Aviso não encontrado.');
  if (!a.channelId) throw new Error('Escolha o canal de publicação do aviso primeiro.');
  const ch = await i.guild.channels.fetch(a.channelId).catch(() => null);
  if (!ch?.isTextBased()) throw new Error('Canal inválido.');
  const payload = { ...ui.renderTemplate(templates.get(i.guildId, ref), templates.varsFor(i.user, i.guild), ref), allowedMentions: { parse: ['users', 'roles', 'everyone'] } };
  let msg = null;
  if (a.messageId && a.messageChannelId === ch.id) msg = await ch.messages.fetch(a.messageId).catch(() => null);
  if (msg) await msg.edit(payload);
  else msg = await ch.send(payload);
  store.update(i.guildId, 'announcements', (d) => {
    d.items[id].messageId = msg.id;
    d.items[id].messageChannelId = ch.id;
  });
  return `✅ Aviso publicado em <#${ch.id}>.`;
}

async function remove(guild, id) {
  const a = store.get(guild.id, 'announcements').items[id];
  if (!a) return;
  if (a.messageId && a.messageChannelId) {
    const ch = await guild.channels.fetch(a.messageChannelId).catch(() => null);
    await ch?.messages?.delete(a.messageId).catch(() => {});
  }
  store.update(guild.id, 'announcements', (d) => {
    delete d.items[id];
  });
  templates.remove(guild.id, `ann.${id}`);
}

templates.registerKind('ann', { back: (ref) => `cfg:ann:${ref.split('.')[1]}`, publish, publishLabel: 'Publicar / atualizar' });

module.exports = { publish, remove };
