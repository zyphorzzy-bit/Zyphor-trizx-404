const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder,
  MediaGalleryItemBuilder, SectionBuilder, ThumbnailBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, UserSelectMenuBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder, MessageFlags,
} = require('discord.js');
const { COLORS } = require('./constants');
const { trunc, chunk, fmtVars, parseEmoji, colorInt } = require('./util');

const V2 = MessageFlags.IsComponentsV2;
const EPH = MessageFlags.Ephemeral;

const STYLES = { primary: 1, secondary: 2, success: 3, danger: 4 };
const STYLE_WORDS = { azul: 1, blue: 1, primary: 1, cinza: 2, gray: 2, grey: 2, secondary: 2, verde: 3, green: 3, success: 3, vermelho: 4, red: 4, danger: 4 };
const styleFromInput = (t) => STYLE_WORDS[String(t || '').trim().toLowerCase()] || 2;

const td = (t) => new TextDisplayBuilder().setContent(String(t || '').trim() ? trunc(t, 3900) : '​');
const sep = (big = false) => new SeparatorBuilder().setDivider(true).setSpacing(big ? SeparatorSpacingSize.Large : SeparatorSpacingSize.Small);
const row = (...c) => new ActionRowBuilder().addComponents(...c.flat().filter(Boolean));

function btn(id, label, { style = 'secondary', emoji, disabled = false } = {}) {
  const b = new ButtonBuilder().setCustomId(id).setStyle(STYLES[style] || 2).setDisabled(disabled);
  if (label) b.setLabel(trunc(label, 80));
  const em = parseEmoji(emoji);
  if (em) b.setEmoji(em);
  return b;
}
function linkBtn(url, label) {
  return new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(url).setLabel(trunc(label, 80));
}
function strSel(id, placeholder, options, { min = 1, max = 1 } = {}) {
  const opts = options.slice(0, 25);
  if (!opts.length) return null;
  const s = new StringSelectMenuBuilder().setCustomId(id).setPlaceholder(trunc(placeholder, 150));
  s.addOptions(
    opts.map((o) => {
      const x = { label: trunc(o.label, 100) || '—', value: String(o.value).slice(0, 100), default: !!o.default };
      if (o.description) x.description = trunc(o.description, 100);
      const em = parseEmoji(o.emoji);
      if (em) x.emoji = em;
      return x;
    }),
  );
  s.setMinValues(Math.min(min, opts.length)).setMaxValues(Math.min(max, opts.length));
  return s;
}
function roleSel(id, placeholder, selected = [], { min = 0, max = 25 } = {}) {
  const s = new RoleSelectMenuBuilder().setCustomId(id).setPlaceholder(trunc(placeholder, 150)).setMinValues(min).setMaxValues(max);
  if (selected.length) s.setDefaultRoles(...selected.slice(0, max));
  return s;
}
function chanSel(id, placeholder, types, selected = [], { min = 0, max = 1 } = {}) {
  const s = new ChannelSelectMenuBuilder().setCustomId(id).setPlaceholder(trunc(placeholder, 150)).setChannelTypes(types).setMinValues(min).setMaxValues(max);
  if (selected.length) s.setDefaultChannels(...selected.slice(0, max));
  return s;
}
function userSel(id, placeholder, { min = 1, max = 1, selected = [] } = {}) {
  const s = new UserSelectMenuBuilder().setCustomId(id).setPlaceholder(trunc(placeholder, 150)).setMinValues(min).setMaxValues(max);
  if (selected.length) s.setDefaultUsers(...selected.slice(0, max));
  return s;
}

function modal(id, title, fields) {
  const m = new ModalBuilder().setCustomId(id).setTitle(trunc(title, 45));
  for (const f of fields.slice(0, 5)) {
    const t = new TextInputBuilder()
      .setCustomId(f.id)
      .setLabel(trunc(f.label, 45))
      .setStyle(f.paragraph ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setRequired(f.required !== false)
      .setMaxLength(f.max || (f.paragraph ? 4000 : 200));
    if (f.placeholder) t.setPlaceholder(trunc(f.placeholder, 100));
    if (f.value) t.setValue(trunc(f.value, f.max || (f.paragraph ? 4000 : 200)));
    m.addComponents(new ActionRowBuilder().addComponents(t));
  }
  return m;
}

// Painel V2 padrão (contêiner com texto + linhas de componentes)
function page({ title, text, rows = [], color = COLORS.brand, footer }) {
  const c = new ContainerBuilder().setAccentColor(color);
  c.addTextDisplayComponents(td(`## ${title}${text ? `\n${text}` : ''}`));
  const rs = rows.filter(Boolean);
  if (rs.length) c.addSeparatorComponents(sep());
  for (const r of rs) c.addActionRowComponents(r);
  if (footer) c.addTextDisplayComponents(td(`-# ${footer}`));
  return { components: [c], flags: V2 };
}
const ephemeral = (p) => ({ ...p, flags: (p.flags || 0) | EPH });

function tplButton(b, i, ref) {
  const bt = new ButtonBuilder();
  const label = b.label ? trunc(b.label, 80) : null;
  if (label) bt.setLabel(label);
  const em = parseEmoji(b.emoji);
  if (em) bt.setEmoji(em);
  if (!label && !em) bt.setLabel('Botão');
  if (b.type === 'link' && b.url) return bt.setStyle(ButtonStyle.Link).setURL(b.url);
  return bt.setStyle(STYLES[b.color] || styleFromInput(b.color) || 2).setCustomId(`btn:${ref}:${i}`);
}

const TPL_BASE = {
  format: 'v2', title: '', description: '', thumbnail: '', banner: '', footer: '', color: '#5865F2', buttons: [], sections: [],
};

// Renderiza um template (Components V2 ou Embed) com variáveis e botões personalizados
function renderTemplate(tpl, vars = {}, ref = 'x', extraRows = []) {
  tpl = { ...TPL_BASE, ...tpl };
  const f = (s) => fmtVars(s, vars);
  const btns = (tpl.buttons || []).slice(0, 20).map((b, i) => tplButton(b, i, ref));
  const all = [...chunk(btns, 5).map((r) => row(r)), ...extraRows].slice(0, 5);
  const title = f(tpl.title);
  const desc = f(tpl.description);
  const sections = (tpl.sections || []).slice(0, 10);

  if (tpl.format === 'embed') {
    const e = new EmbedBuilder().setColor(colorInt(tpl.color)).setDescription(trunc(desc || '​', 4000));
    if (title) e.setTitle(trunc(title, 256));
    if (tpl.thumbnail) e.setThumbnail(tpl.thumbnail);
    if (tpl.banner) e.setImage(tpl.banner);
    for (const s of sections) e.addFields({ name: trunc(f(s.title) || '​', 256), value: trunc(f(s.text) || '​', 1024) });
    if (tpl.footer) e.setFooter({ text: trunc(f(tpl.footer), 2048) });
    return { embeds: [e], components: all };
  }

  let budget = 3800;
  const take = (s) => {
    s = trunc(s, Math.max(budget, 0));
    budget -= s.length;
    return s;
  };
  const c = new ContainerBuilder().setAccentColor(colorInt(tpl.color));
  const head = [title ? `## ${title}` : '', desc].filter(Boolean).join('\n');
  if (tpl.thumbnail) {
    c.addSectionComponents(new SectionBuilder().addTextDisplayComponents(td(take(head))).setThumbnailAccessory(new ThumbnailBuilder().setURL(tpl.thumbnail)));
  } else c.addTextDisplayComponents(td(take(head)));
  if (tpl.banner) c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(tpl.banner)));
  for (const s of sections) {
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(td(take(`### ${f(s.title)}\n${f(s.text)}`)));
  }
  if (tpl.footer) {
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(td(take(`-# ${f(tpl.footer)}`)));
  }
  if (all.length) {
    c.addSeparatorComponents(sep());
    for (const r of all) c.addActionRowComponents(r);
  }
  return { components: [c], flags: V2 };
}

const stars = (n) => '⭐'.repeat(n) + '☆'.repeat(5 - n);

module.exports = {
  V2, EPH, COLORS, td, sep, row, btn, linkBtn, strSel, roleSel, chanSel, userSel, modal, page, ephemeral,
  renderTemplate, TPL_BASE, styleFromInput, stars,
};
