const store = require('./storage');
const ui = require('./ui');
const { log } = require('./logs');
const { uid, fmtVars, fmtDuration, trunc } = require('./util');
const { OWNER_ID } = require('./constants');

const TYPES = { warn: 'Advertência', timeout: 'Timeout (castigo)', kick: 'Expulsão', ban: 'Banimento', unban: 'Remoção de banimento', clear: 'Limpeza de mensagens' };
const DEFAULT_MSG = {
  warn: 'Você recebeu uma **advertência** em **{server}**.\n**Motivo:** {reason}',
  timeout: 'Você recebeu um **castigo (timeout)** de {duration} em **{server}**.\n**Motivo:** {reason}',
  kick: 'Você foi **expulso(a)** de **{server}**.\n**Motivo:** {reason}',
  ban: 'Você foi **banido(a)** de **{server}**.\n**Motivo:** {reason}',
};
const MAX_TIMEOUT = 28 * 24 * 60 * 60 * 1000;

function messageFor(gid, type) {
  return store.get(gid, 'moderation').settings.messages[type] || DEFAULT_MSG[type];
}

// Aplica uma punição de verdade e registra (usuário, moderador, motivo, data, tipo).
async function apply(guild, { targetId, moderator, type, reason, durationMs = 0, source = 'manual' }) {
  reason = trunc(reason || 'Sem motivo informado', 400);
  const modId = moderator?.id || guild.client.user.id;
  const modMember = moderator?.member || null;
  const me = guild.members.me;
  const target = await guild.members.fetch(targetId).catch(() => null);
  const user = target?.user || (await guild.client.users.fetch(targetId).catch(() => null));

  if (type !== 'unban' && targetId === guild.ownerId) return { ok: false, error: 'Não é possível punir o dono do servidor.' };
  if (targetId === guild.client.user.id) return { ok: false, error: 'Não posso punir a mim mesmo.' };
  if (target) {
    if (target.roles.highest.position >= me.roles.highest.position) return { ok: false, error: 'O cargo do alvo é igual ou maior que o do bot.' };
    if (modMember && modMember.id !== guild.ownerId && modMember.id !== OWNER_ID && target.roles.highest.position >= modMember.roles.highest.position) {
      return { ok: false, error: 'O cargo do alvo é igual ou maior que o seu.' };
    }
  } else if (type === 'timeout' || type === 'kick') {
    return { ok: false, error: 'O usuário não está no servidor.' };
  }

  const ms = type === 'timeout' ? Math.min(Math.max(durationMs, 60000), MAX_TIMEOUT) : 0;
  const vars = { user: `<@${targetId}>`, username: user?.username || targetId, server: guild.name, reason, moderator: `<@${modId}>`, type: TYPES[type], duration: ms ? fmtDuration(ms) : '—' };

  // DM antes de expulsar/banir (depois o usuário não compartilha mais servidor com o bot)
  let dmSent = null;
  if (user && type !== 'unban' && store.get(guild.id, 'moderation').settings.dm) {
    dmSent = await user.send(ui.page({ title: `⚖️ ${TYPES[type]}`, text: fmtVars(messageFor(guild.id, type), vars), color: ui.COLORS.err })).then(() => true).catch(() => false);
  }

  try {
    if (type === 'timeout') await target.timeout(ms, reason);
    else if (type === 'kick') await target.kick(reason);
    else if (type === 'ban') await guild.members.ban(targetId, { reason, deleteMessageSeconds: 0 });
    else if (type === 'unban') await guild.bans.remove(targetId, reason);
    else if (type !== 'warn') return { ok: false, error: 'Tipo inválido.' };
  } catch (e) {
    return { ok: false, error: `O Discord recusou a ação: ${e.message}` };
  }

  const record = { id: uid(8), userId: targetId, userTag: user?.username || null, moderatorId: modId, type, reason, at: Date.now(), durationMs: ms, source };
  store.update(guild.id, 'moderation', (d) => {
    d.punishments.push(record);
    if (d.punishments.length > 5000) d.punishments.splice(0, d.punishments.length - 5000);
  });
  await log(guild, 'moderation', {
    title: `${TYPES[type]}`,
    description: `**Usuário:** <@${targetId}> (${targetId})\n**Moderador:** <@${modId}>\n**Motivo:** ${reason}${ms ? `\n**Duração:** ${fmtDuration(ms)}` : ''}\n**Origem:** ${source}${dmSent === false ? '\n*DM não entregue (fechada).*' : ''}`,
  });
  return { ok: true, record, dmSent };
}

async function clearMessages(guild, channel, count, moderator) {
  const n = Math.min(Math.max(count, 1), 100);
  const deleted = await channel.bulkDelete(n, true);
  const record = { id: uid(8), userId: null, moderatorId: moderator.id, type: 'clear', reason: `${deleted.size} mensagens em #${channel.name}`, at: Date.now(), durationMs: 0, source: 'manual' };
  store.update(guild.id, 'moderation', (d) => d.punishments.push(record));
  await log(guild, 'moderation', { title: TYPES.clear, description: `**Moderador:** <@${moderator.id}>\n**Canal:** <#${channel.id}>\n**Apagadas:** ${deleted.size}` });
  return deleted.size;
}

const history = (gid, userId, n = 10) => store.get(gid, 'moderation').punishments.filter((p) => p.userId === userId).slice(-n).reverse();
const recent = (gid, n = 8) => store.get(gid, 'moderation').punishments.slice(-n).reverse();

function line(p) {
  return `\`${p.id}\` **${TYPES[p.type]}** ${p.userId ? `<@${p.userId}>` : ''} — ${trunc(p.reason, 60)} • por <@${p.moderatorId}> • <t:${Math.floor(p.at / 1000)}:f>`;
}

module.exports = { apply, clearMessages, history, recent, line, TYPES, DEFAULT_MSG };
