// Editor genérico de mensagens (Components V2 / Embed) usado por boas-vindas, regras, avisos,
// aviso do honeypot, painéis de ticket e pedido de feedback.
const { MessageFlags } = require('discord.js');
const store = require('./storage');
const ui = require('./ui');
const { trunc, isUrl, parseColor, parseEmoji } = require('./util');
const { hasPerm } = require('./permissions');
const { log } = require('./logs');

const PRESETS = {
  'welcome.join': { title: 'Bem-vindo(a), {username}!', description: 'Olá {user}, seja bem-vindo(a) a **{server}**! Agora somos {memberCount} membros.', color: '#57F287' },
  'welcome.leave': { title: 'Até logo!', description: '**{username}** saiu de **{server}**. Agora somos {memberCount} membros.', color: '#ED4245' },
  'rules.main': {
    title: '📜 Regras do servidor',
    description: 'Leia com atenção. Ao permanecer em **{server}** você concorda com as regras abaixo.',
    sections: [
      { title: 'Regras gerais', text: '1. Respeite todos os membros.\n2. Sem spam, flood ou divulgação não autorizada.\n3. Siga os Termos de Serviço do Discord.' },
      { title: 'Avisos', text: 'A equipe pode alterar as regras a qualquer momento.' },
      { title: 'Consequências', text: 'O descumprimento pode resultar em advertência, castigo, expulsão ou banimento.' },
    ],
  },
  'honeypot.warn': {
    title: '⚠️ Canal armadilha (Honeypot)',
    description: '**Não envie mensagens neste canal.** Qualquer mensagem enviada aqui será apagada automaticamente e poderá resultar em punição.\n\nApenas ler este aviso não causa punição.',
    color: '#ED4245',
  },
  'feedback.request': { title: 'Avalie seu atendimento', description: 'Seu ticket em **{server}** foi encerrado. Como foi o atendimento? Escolha de 1 a 5 estrelas e, se quiser, deixe um comentário.' },
  'ticket.panel': { title: '📩 Central de atendimento', description: 'Selecione abaixo o tipo de atendimento que você precisa.' },
  ann: { title: 'Novo aviso', description: 'Edite este aviso em /config → Avisos.' },
};

const kinds = [];
function registerKind(prefix, def) {
  kinds.push({ prefix, ...def });
  kinds.sort((a, b) => b.prefix.length - a.prefix.length);
}
const kindOf = (ref) => kinds.find((k) => ref === k.prefix || ref.startsWith(k.prefix + '.'));

function preset(ref) {
  const parts = ref.split('.');
  return PRESETS[ref] || PRESETS[parts.slice(0, -1).join('.')] || PRESETS[parts[0]] || {};
}
function get(gid, ref) {
  const saved = store.get(gid, 'templates').items[ref];
  return { ...ui.TPL_BASE, ...structuredClone(preset(ref)), ...(saved ? structuredClone(saved) : {}) };
}
function set(gid, ref, tpl) {
  store.update(gid, 'templates', (d) => {
    d.items[ref] = tpl;
  });
}
function remove(gid, ref) {
  store.update(gid, 'templates', (d) => {
    delete d.items[ref];
  });
}
const varsFor = (user, guild) => ({ user: `<@${user.id}>`, username: user.username, server: guild.name, memberCount: guild.memberCount });

function editor(gid, ref) {
  const t = get(gid, ref);
  const k = kindOf(ref);
  const text = [
    `**Formato:** ${t.format === 'embed' ? 'Embed' : 'Components V2'}`,
    `**Título:** ${trunc(t.title || '—', 100)}`,
    `**Descrição:** ${trunc(t.description || '—', 200)}`,
    `**Rodapé:** ${trunc(t.footer || '—', 80)}   **Cor:** ${t.color}`,
    `**Imagem (miniatura):** ${t.thumbnail ? '✅' : '—'}   **Banner:** ${t.banner ? '✅' : '—'}`,
    `**Botões:** ${t.buttons.length}   **Seções:** ${t.sections.length}`,
    '',
    '-# Variáveis: {user} {username} {server} {memberCount} • Emojis personalizados: <:nome:id>',
  ].join('\n');
  return ui.page({
    title: '🎨 Editor de mensagem',
    text,
    rows: [
      ui.row(ui.btn(`tpl:text:${ref}`, 'Texto', { style: 'primary' }), ui.btn(`tpl:img:${ref}`, 'Imagens e cor'), ui.btn(`tpl:fmt:${ref}`, `Formato: ${t.format === 'embed' ? 'Embed' : 'V2'}`), ui.btn(`tpl:list:${ref}:b:-1`, 'Botões'), ui.btn(`tpl:list:${ref}:s:-1`, 'Seções')),
      ui.row(ui.btn(`tpl:prev:${ref}`, 'Prévia', { style: 'success' }), k?.publish ? ui.btn(`tpl:pub:${ref}`, k.publishLabel || 'Publicar', { style: 'success' }) : null, ui.btn(k?.back ? k.back(ref) : 'cfg:home', '← Voltar')),
    ],
  });
}

function listPage(gid, ref, kind, sel) {
  const t = get(gid, ref);
  const items = kind === 'b' ? t.buttons : t.sections;
  const noun = kind === 'b' ? 'Botões' : 'Seções';
  sel = Number(sel);
  if (!(sel >= 0 && sel < items.length)) sel = -1;
  const lines = items.map((it, i) => `${i === sel ? '▶' : '•'} ${i + 1}. ${kind === 'b' ? `${it.emoji || ''} ${it.label || '(sem texto)'} — ${it.type === 'link' ? 'link' : it.type === 'role' ? 'cargo' : 'resposta'}` : trunc(it.title, 60)}`);
  const sl = ui.strSel(`tpl:lsel:${ref}:${kind}`, `Selecione um item de ${noun.toLowerCase()}`, items.map((it, i) => ({ label: `${i + 1}. ${kind === 'b' ? it.label || it.emoji || 'Botão' : it.title}`, value: String(i), default: i === sel })));
  const none = sel < 0;
  return ui.page({
    title: `🧩 ${noun}`,
    text: (lines.join('\n') || '*Nenhum item ainda.*') + (kind === 'b' ? '\n\n-# Tipos: link (abre URL), resposta (mensagem privada), cargo (dá/remove um cargo).' : ''),
    rows: [
      sl ? ui.row(sl) : null,
      ui.row(
        ui.btn(`tpl:ladd:${ref}:${kind}`, 'Adicionar', { style: 'success' }),
        ui.btn(`tpl:ledit:${ref}:${kind}:${sel}`, 'Editar', { disabled: none }),
        ui.btn(`tpl:lup:${ref}:${kind}:${sel}`, '⬆', { disabled: none || sel === 0 }),
        ui.btn(`tpl:ldown:${ref}:${kind}:${sel}`, '⬇', { disabled: none || sel === items.length - 1 }),
        ui.btn(`tpl:ldel:${ref}:${kind}:${sel}`, 'Remover', { style: 'danger', disabled: none }),
      ),
      ui.row(ui.btn(`tpl:main:${ref}`, '← Voltar ao editor')),
    ],
  });
}

function buttonModal(ref, type, sel, roleId, existing) {
  const fields = [
    { id: 'label', label: 'Texto do botão', required: false, max: 80, value: existing?.label },
    { id: 'emoji', label: 'Emoji (opcional)', required: false, max: 60, placeholder: '😀 ou <:nome:id>', value: existing?.emoji },
  ];
  if (type === 'link') fields.push({ id: 'value', label: 'URL (https://...)', max: 500, value: existing?.url });
  if (type === 'reply') fields.push({ id: 'value', label: 'Resposta enviada ao clicar', paragraph: true, max: 1900, value: existing?.text });
  if (type !== 'link') fields.push({ id: 'color', label: 'Cor: azul, cinza, verde ou vermelho', required: false, max: 20, value: existing?.color });
  return ui.modal(`tpl:mbtn:${ref}:${type}:${sel}:${roleId || '-'}`, type === 'link' ? 'Botão de link' : type === 'reply' ? 'Botão de resposta' : 'Botão de cargo', fields);
}

const auditAct = new Set(['mtext', 'mimg', 'msec', 'mbtn', 'fmt', 'lup', 'ldown', 'ldel', 'pub']);

async function handle(i) {
  const [, act, ref, kind, sel, extra] = i.customId.split(':');
  const gid = i.guildId;
  if (!i.guild || !hasPerm(gid, i.member, i.user.id, 'config')) {
    return i.reply({ content: '❌ Você não tem permissão para editar mensagens.', flags: ui.EPH });
  }
  const upd = (p) => i.update(p);
  let notice = null;
  const t = get(gid, ref);

  switch (act) {
    case 'main':
      return upd(editor(gid, ref));
    case 'text':
      return i.showModal(ui.modal(`tpl:mtext:${ref}`, 'Texto da mensagem', [
        { id: 'title', label: 'Título', required: false, max: 256, value: t.title },
        { id: 'desc', label: 'Descrição', paragraph: true, required: false, max: 3000, value: t.description },
        { id: 'footer', label: 'Rodapé', required: false, max: 200, value: t.footer },
      ]));
    case 'mtext':
      t.title = i.fields.getTextInputValue('title');
      t.description = i.fields.getTextInputValue('desc');
      t.footer = i.fields.getTextInputValue('footer');
      set(gid, ref, t);
      break;
    case 'img':
      return i.showModal(ui.modal(`tpl:mimg:${ref}`, 'Imagens e cor', [
        { id: 'thumb', label: 'Imagem pequena (URL)', required: false, max: 500, value: t.thumbnail },
        { id: 'banner', label: 'Banner grande (URL)', required: false, max: 500, value: t.banner },
        { id: 'color', label: 'Cor (hex, ex.: #5865F2)', required: false, max: 7, value: t.color },
      ]));
    case 'mimg': {
      const th = i.fields.getTextInputValue('thumb').trim();
      const bn = i.fields.getTextInputValue('banner').trim();
      if ((th && !isUrl(th)) || (bn && !isUrl(bn))) return i.reply({ content: '❌ As imagens precisam ser URLs http(s) válidas.', flags: ui.EPH });
      t.thumbnail = th;
      t.banner = bn;
      t.color = parseColor(i.fields.getTextInputValue('color'), t.color);
      set(gid, ref, t);
      break;
    }
    case 'fmt':
      t.format = t.format === 'embed' ? 'v2' : 'embed';
      set(gid, ref, t);
      break;
    case 'prev':
      return i.reply(ui.ephemeral(ui.renderTemplate(t, varsFor(i.user, i.guild), ref)));
    case 'pub': {
      const k = kindOf(ref);
      if (!k?.publish) return i.reply({ content: '❌ Esta mensagem não é publicável aqui.', flags: ui.EPH });
      await i.deferUpdate();
      notice = await k.publish(i, ref).catch((e) => `❌ ${e.message}`);
      await i.editReply(editor(gid, ref));
      await i.followUp({ content: notice, flags: ui.EPH });
      await log(i.guild, 'admin', { title: 'Mensagem publicada', description: `<@${i.user.id}> publicou \`${ref}\`` });
      return;
    }
    // ---- listas (botões / seções) ----
    case 'list':
      return upd(listPage(gid, ref, kind, sel));
    case 'lsel':
      return upd(listPage(gid, ref, kind, i.values[0]));
    case 'ladd':
      if (kind === 's') {
        if (t.sections.length >= 10) return i.reply({ content: '❌ Máximo de 10 seções.', flags: ui.EPH });
        return i.showModal(ui.modal(`tpl:msec:${ref}:new`, 'Nova seção', [{ id: 'title', label: 'Título da seção', max: 200 }, { id: 'text', label: 'Texto', paragraph: true, max: 1000 }]));
      }
      if (t.buttons.length >= 20) return i.reply({ content: '❌ Máximo de 20 botões.', flags: ui.EPH });
      return upd(ui.page({
        title: 'Novo botão',
        text: 'Escolha o tipo de botão:',
        rows: [ui.row(ui.strSel(`tpl:btype:${ref}`, 'Tipo do botão', [
          { label: 'Link', value: 'link', description: 'Abre uma URL', emoji: '🔗' },
          { label: 'Resposta', value: 'reply', description: 'Envia uma mensagem privada ao clicar', emoji: '💬' },
          { label: 'Cargo', value: 'role', description: 'Dá ou remove um cargo ao clicar', emoji: '🏷️' },
        ])), ui.row(ui.btn(`tpl:list:${ref}:b:-1`, '← Cancelar'))],
      }));
    case 'btype': {
      const type = i.values[0];
      if (type === 'role') {
        return upd(ui.page({
          title: 'Botão de cargo',
          text: 'Escolha o cargo que o botão vai dar/remover:',
          rows: [ui.row(ui.roleSel(`tpl:brole:${ref}`, 'Selecione o cargo', [], { min: 1, max: 1 })), ui.row(ui.btn(`tpl:list:${ref}:b:-1`, '← Cancelar'))],
        }));
      }
      return i.showModal(buttonModal(ref, type, 'new', null));
    }
    case 'brole':
      return i.showModal(buttonModal(ref, 'role', 'new', i.values[0]));
    case 'ledit': {
      const idx = Number(sel);
      if (kind === 's') {
        const s = t.sections[idx];
        return i.showModal(ui.modal(`tpl:msec:${ref}:${idx}`, 'Editar seção', [{ id: 'title', label: 'Título da seção', max: 200, value: s.title }, { id: 'text', label: 'Texto', paragraph: true, max: 1000, value: s.text }]));
      }
      const b = t.buttons[idx];
      return i.showModal(buttonModal(ref, b.type, idx, b.roleId, b));
    }
    case 'msec': {
      const entry = { title: i.fields.getTextInputValue('title'), text: i.fields.getTextInputValue('text') };
      if (kind === 'new') t.sections.push(entry);
      else t.sections[Number(kind)] = entry;
      set(gid, ref, t);
      return upd(listPage(gid, ref, 's', kind === 'new' ? t.sections.length - 1 : kind));
    }
    case 'mbtn': {
      // customId: tpl:mbtn:<ref>:<type>:<sel>:<role>
      const type = kind;
      const idx = sel;
      const roleId = extra && extra !== '-' ? extra : null;
      const label = i.fields.getTextInputValue('label').trim();
      const emoji = i.fields.getTextInputValue('emoji').trim();
      if (emoji && !parseEmoji(emoji)) return i.reply({ content: '❌ Emoji inválido. Use um emoji normal ou o formato <:nome:id>.', flags: ui.EPH });
      if (!label && !emoji) return i.reply({ content: '❌ Informe um texto ou um emoji.', flags: ui.EPH });
      const entry = { type, label, emoji };
      if (type === 'link') {
        const url = i.fields.getTextInputValue('value').trim();
        if (!isUrl(url)) return i.reply({ content: '❌ URL inválida.', flags: ui.EPH });
        entry.url = url;
      } else {
        if (type === 'reply') entry.text = i.fields.getTextInputValue('value');
        if (type === 'role') entry.roleId = roleId;
        entry.color = i.fields.getTextInputValue('color').trim().toLowerCase() || 'cinza';
      }
      if (idx === 'new') t.buttons.push(entry);
      else t.buttons[Number(idx)] = entry;
      set(gid, ref, t);
      return upd(listPage(gid, ref, 'b', idx === 'new' ? t.buttons.length - 1 : idx));
    }
    case 'lup':
    case 'ldown':
    case 'ldel': {
      const arr = kind === 'b' ? t.buttons : t.sections;
      const idx = Number(sel);
      if (!(idx >= 0 && idx < arr.length)) return upd(listPage(gid, ref, kind, -1));
      let newSel = idx;
      if (act === 'ldel') {
        arr.splice(idx, 1);
        newSel = -1;
      } else {
        const to = act === 'lup' ? idx - 1 : idx + 1;
        if (to < 0 || to >= arr.length) return upd(listPage(gid, ref, kind, idx));
        [arr[idx], arr[to]] = [arr[to], arr[idx]];
        newSel = to;
      }
      set(gid, ref, t);
      await upd(listPage(gid, ref, kind, newSel));
      return log(i.guild, 'admin', { title: 'Mensagem editada', description: `<@${i.user.id}> alterou \`${ref}\` (${act})` });
    }
    default:
      return;
  }
  // mtext / mimg / fmt voltam ao editor
  await upd(editor(gid, ref));
  if (auditAct.has(act)) await log(i.guild, 'admin', { title: 'Mensagem editada', description: `<@${i.user.id}> alterou \`${ref}\` (${act})` });
}

// Cliques nos botões publicados (resposta / cargo)
async function handleButton(i) {
  const [, ref, idxStr] = i.customId.split(':');
  const t = get(i.guildId, ref);
  const b = t.buttons[Number(idxStr)];
  if (!b) return i.reply({ content: '❌ Este botão não existe mais.', flags: ui.EPH });
  if (b.type === 'reply') {
    const { fmtVars } = require('./util');
    return i.reply({ content: trunc(fmtVars(b.text || '—', varsFor(i.user, i.guild)), 2000), flags: ui.EPH });
  }
  if (b.type === 'role') {
    const role = i.guild.roles.cache.get(b.roleId);
    const me = i.guild.members.me;
    if (!role) return i.reply({ content: '❌ O cargo deste botão foi removido.', flags: ui.EPH });
    if (role.managed || role.position >= me.roles.highest.position || !me.permissions.has('ManageRoles')) {
      return i.reply({ content: '❌ Não consigo gerenciar esse cargo (hierarquia ou permissão do bot).', flags: ui.EPH });
    }
    const has = i.member.roles.cache.has(role.id);
    try {
      if (has) await i.member.roles.remove(role, 'Botão de cargo');
      else await i.member.roles.add(role, 'Botão de cargo');
    } catch (e) {
      return i.reply({ content: `❌ Falha: ${e.message}`, flags: ui.EPH });
    }
    return i.reply({ content: has ? `✅ Cargo **${role.name}** removido.` : `✅ Cargo **${role.name}** adicionado.`, flags: ui.EPH });
  }
  return i.reply({ content: 'Este botão é um link.', flags: ui.EPH });
}

module.exports = { get, set, remove, editor, registerKind, handle, handleButton, varsFor, PRESETS };
