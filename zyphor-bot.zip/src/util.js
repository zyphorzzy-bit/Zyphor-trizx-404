const crypto = require('crypto');

const uid = (n = 6) => crypto.randomBytes(8).toString('hex').slice(0, n);
const trunc = (s, n) => {
  s = String(s ?? '');
  return s.length > n ? s.slice(0, Math.max(0, n - 1)) + '…' : s;
};
const chunk = (a, n) => {
  const o = [];
  for (let i = 0; i < a.length; i += n) o.push(a.slice(i, i + n));
  return o;
};
const fmtVars = (t, v) => String(t ?? '').replace(/\{(\w+)\}/g, (m, k) => (k in v ? String(v[k]) : m));
const BRL = (v) => Number(v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const ts = (d = Date.now(), f = 'f') => `<t:${Math.floor(d / 1000)}:${f}>`;

function parseEmoji(input) {
  if (!input) return null;
  const s = String(input).trim();
  if (!s) return null;
  const m = s.match(/^<(a?):(\w+):(\d+)>$/);
  if (m) return { id: m[3], name: m[2], animated: !!m[1] };
  if (/[^\x00-\x7F]/.test(s) && s.length <= 16) return s;
  return null;
}
function isUrl(s) {
  try {
    const u = new URL(s);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}
function parseColor(s, def = '#5865F2') {
  s = String(s || '').trim();
  return /^#?[0-9a-f]{6}$/i.test(s) ? '#' + s.replace('#', '') : def;
}
const colorInt = (h) => parseInt(String(h).replace('#', ''), 16) || 0x5865f2;

function fmtDuration(ms) {
  const m = Math.round(ms / 60000);
  if (m < 60) return `${m} min`;
  if (m < 1440) return `${Math.round(m / 60)} h`;
  return `${Math.round(m / 1440)} dia(s)`;
}

module.exports = { uid, trunc, chunk, fmtVars, BRL, ts, parseEmoji, isUrl, parseColor, colorInt, fmtDuration };
