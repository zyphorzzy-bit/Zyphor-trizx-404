// Armazenamento 100% em arquivos JSON: data/guilds/<guildId>/<modulo>.json
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), 'data'));
const GUILDS_DIR = path.join(DATA_DIR, 'guilds');
const BACKUPS_DIR = path.join(DATA_DIR, 'backups');

const DEFAULTS = {
  core: { permissions: {}, logs: {} },
  templates: { items: {} },
  tickets: {
    settings: { enabled: true, mode: 'channel', destination: null },
    panels: {},
    categories: {},
    open: {},
    closed: {},
    counter: 0,
  },
  shop: { products: {}, deliveries: [] },
  feedback: { settings: { enabled: true, channelId: null }, pending: {}, entries: [] },
  moderation: { settings: { dm: true, messages: {} }, punishments: [] },
  security: { rules: {}, events: [] },
  honeypot: {
    enabled: false,
    channelId: null,
    publishChannelId: null,
    messageId: null,
    action: 'timeout',
    days: 7,
    exemptRoles: [],
    events: [],
  },
  welcome: { join: { enabled: false, channelId: null }, leave: { enabled: false, channelId: null } },
  announcements: { items: {} },
  rules: { channelId: null, messageId: null },
  ai: { modes: { tickets: 'off', security: 'off', rules: 'off', reports: 'off' }, context: '' },
  logs: { entries: [] },
};

const cache = new Map();

function merge(def, data) {
  if (Array.isArray(def)) return Array.isArray(data) ? data : structuredClone(def);
  if (def && typeof def === 'object') {
    const src = data && typeof data === 'object' && !Array.isArray(data) ? data : {};
    const out = {};
    for (const k of new Set([...Object.keys(def), ...Object.keys(src)])) {
      const dv = def[k];
      if (k in def && dv && typeof dv === 'object' && !Array.isArray(dv) && Object.keys(dv).length) out[k] = merge(dv, src[k]);
      else out[k] = k in src ? src[k] : structuredClone(dv);
    }
    return out;
  }
  return data === undefined ? def : data;
}

function fileOf(guildId, mod) {
  if (!/^\d+$/.test(String(guildId))) throw new Error('guildId inválido');
  if (!(mod in DEFAULTS)) throw new Error(`módulo desconhecido: ${mod}`);
  return path.join(GUILDS_DIR, String(guildId), `${mod}.json`);
}

function tryParse(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function load(guildId, mod) {
  const file = fileOf(guildId, mod);
  let raw = null;
  try {
    raw = tryParse(file);
  } catch (e) {
    if (e.code !== 'ENOENT') {
      console.error(`[storage] erro lendo ${file}: ${e.message}`);
      try {
        raw = tryParse(file + '.bak');
        console.warn(`[storage] recuperado de ${file}.bak`);
      } catch {
        try {
          fs.renameSync(file, `${file}.corrupt-${Date.now()}`);
        } catch {}
      }
    }
  }
  return merge(DEFAULTS[mod], raw);
}

function get(guildId, mod) {
  const key = `${guildId}:${mod}`;
  if (!cache.has(key)) cache.set(key, load(guildId, mod));
  return cache.get(key);
}

function writeAtomic(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, content);
  try {
    if (fs.existsSync(file)) fs.copyFileSync(file, file + '.bak');
  } catch {}
  fs.renameSync(tmp, file);
}

function save(guildId, mod) {
  const data = get(guildId, mod);
  try {
    writeAtomic(fileOf(guildId, mod), JSON.stringify(data, null, 2));
  } catch (e) {
    console.error(`[storage] erro gravando ${guildId}/${mod}: ${e.message}`);
    throw e;
  }
}

function update(guildId, mod, fn) {
  const d = get(guildId, mod);
  fn(d);
  save(guildId, mod);
  return d;
}

// arquivos avulsos (transcrições)
function writeFile(guildId, rel, content) {
  if (!/^\d+$/.test(String(guildId)) || rel.includes('..')) throw new Error('caminho inválido');
  writeAtomic(path.join(GUILDS_DIR, String(guildId), rel), content);
}

// ---- backups ----
const STAMP_RE = /^[\w-]+$/;

function prune() {
  const keep = Number(process.env.BACKUP_KEEP || 10);
  const all = listBackups();
  for (const s of all.slice(keep)) fs.rmSync(path.join(BACKUPS_DIR, s), { recursive: true, force: true });
}

function backupNow() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const dest = path.join(BACKUPS_DIR, stamp);
  fs.mkdirSync(dest, { recursive: true });
  if (fs.existsSync(GUILDS_DIR)) {
    fs.cpSync(GUILDS_DIR, dest, {
      recursive: true,
      filter: (p) => !p.endsWith('.tmp') && !p.endsWith('.bak'),
    });
  }
  prune();
  return stamp;
}

function listBackups() {
  try {
    return fs.readdirSync(BACKUPS_DIR).filter((s) => STAMP_RE.test(s)).sort().reverse();
  } catch {
    return [];
  }
}

function backupHasGuild(stamp, guildId) {
  return STAMP_RE.test(stamp) && fs.existsSync(path.join(BACKUPS_DIR, stamp, String(guildId)));
}

function restoreGuild(stamp, guildId) {
  if (!backupHasGuild(stamp, guildId)) throw new Error('Backup não contém dados deste servidor.');
  backupNow(); // ponto de segurança antes de restaurar
  const dest = path.join(GUILDS_DIR, String(guildId));
  fs.rmSync(dest, { recursive: true, force: true });
  fs.cpSync(path.join(BACKUPS_DIR, stamp, String(guildId)), dest, { recursive: true });
  for (const k of [...cache.keys()]) if (k.startsWith(`${guildId}:`)) cache.delete(k);
}

module.exports = { DATA_DIR, get, save, update, writeFile, backupNow, listBackups, backupHasGuild, restoreGuild };
