const store = require('./storage');
const templates = require('./templates');
const ui = require('./ui');
const { hasPerm } = require('./permissions');

const REF = 'rules.main';

async function publish(i) {
  const cfg = store.get(i.guildId, 'rules');
  if (!cfg.channelId) throw new Error('Escolha o canal das regras primeiro.');
  const ch = await i.guild.channels.fetch(cfg.channelId).catch(() => null);
  if (!ch?.isTextBased()) throw new Error('Canal inválido.');
  const payload = {
    ...ui.renderTemplate(templates.get(i.guildId, REF), templates.varsFor(i.user, i.guild), REF, [ui.row(ui.btn('rules:settings', '⚙️ Configurações'))]),
    allowedMentions: { parse: [] },
  };
  let msg = null;
  if (cfg.messageId && cfg.messageChannelId === ch.id) msg = await ch.messages.fetch(cfg.messageId).catch(() => null);
  if (msg) await msg.edit(payload);
  else msg = await ch.send(payload);
  store.update(i.guildId, 'rules', (d) => {
    d.messageId = msg.id;
    d.messageChannelId = ch.id;
  });
  return `✅ Regras publicadas em <#${ch.id}>.`;
}

templates.registerKind('rules', { back: () => 'cfg:rules', publish, publishLabel: 'Publicar regras' });

// Botão "Configurações" da mensagem publicada: só administradores autorizados
async function handle(i, renderRulesPage) {
  if (!hasPerm(i.guildId, i.member, i.user.id, 'config')) {
    return i.reply({ content: '❌ Apenas administradores autorizados podem abrir as configurações.', flags: ui.EPH });
  }
  return i.reply(ui.ephemeral(await renderRulesPage(i)));
}

module.exports = { publish, handle };
