const { OWNER_ID } = require('./constants');
const store = require('./storage');

// 'config' implica todas as permissões. O proprietário principal sempre tem acesso total.
function hasPerm(guildId, member, userId, perm) {
  if (userId === OWNER_ID) return true;
  const roles = member?.roles?.cache;
  if (!roles) return false;
  const core = store.get(guildId, 'core');
  for (const [rid, perms] of Object.entries(core.permissions)) {
    if (roles.has(rid) && (perms.includes('config') || perms.includes(perm))) return true;
  }
  return false;
}

function rolesWithPerm(guildId, perm) {
  const core = store.get(guildId, 'core');
  return Object.entries(core.permissions)
    .filter(([, p]) => p.includes(perm))
    .map(([r]) => r);
}

module.exports = { hasPerm, rolesWithPerm, OWNER_ID };
