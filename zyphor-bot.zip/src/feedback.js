const store = require('./storage');
const templates = require('./templates');
const ui = require('./ui');
const { hasPerm } = require('./permissions');
const { log } = require('./logs');
const { uid, trunc, ts } = require('./util');

templates.registerKind('feedback', { back: () => 'cfg:feedbacks' });

// DM pós-fechamento: 1–5 estrelas + comentário opcional (modal)
async function sendRequest(guild, user, closed) {
  const cfg = store.get(guild.id, 'feedback');
  if (!cfg.enabled) return false;
  store.update(guild.id, 'feedback', (d) => {
    d.pending[closed.number] = { userId: user.id, productId: closed.productId || null, productName: closed.productName || null, at: Date.now() };
  });
  const stars = ui.row([1, 2, 3, 4, 5].map((n) => ui.btn(`fb:r:${guild.id}:${closed.number}:${n}`, `${n} ⭐`, { style: n >= 4 ? 'success' : n === 3 ? 'primary' : 'secondary' })));
  const payload = ui.renderTemplate(templates.get(guild.id, 'feedback.request'), { user: `<@${user.id}>`, username: user.username, server: guild.name, memberCount: guild.memberCount }, 'feedback.request', [stars]);
  const ok = await user.send(payload).then(() => true).catch(() => false);
  if (!ok) await log(guild, 'feedbacks', { title: 'DM de avaliação não entregue', description: `<@${user.id}> está com a DM fechada (ticket #${closed.number}).` });
  return ok;
}

async function publishEntry(guild, entry) {
  const chId = store.get(guild.id, 'feedback').settings?.channelId ?? store.get(guild.id, 'feedback').channelId;
  if (!chId) return;
  const ch = await guild.channels.fetch(chId).catch(() => null);
  if (!ch?.isTextBased()) return;
  const text = [
    `**Cliente:** <@${entry.userId}>`,
    `**Avaliação:** ${ui.stars(entry.stars)} (${entry.stars}/5)`,
    entry.productName ? `**Produto:** ${entry.productName}` : null,
    `**Atendimento:** #${String(entry.number).padStart(4, '0')}`,
    `**Data:** ${ts(entry.at)}`,
    entry.comment ? `\n> ${trunc(entry.comment, 900).replace(/\n/g, '\n> ')}` : null,
  ].filter(Boolean).join('\n');
  await ch.send({ ...ui.page({ title: '⭐ Novo feedback', text, color: entry.stars >= 4 ? ui.COLORS.ok : entry.stars === 3 ? ui.COLORS.warn : ui.COLORS.err }), allowedMentions: { parse: [] } }).catch((e) => console.error('[feedback] publicar:', e.message));
}

// ---- listagem (z!feedbacks) ----
const PAGE = 5;
function listPayload(guild, filter = 'all', page = 0) {
  const d = store.get(guild.id, 'feedback');
  const products = store.get(guild.id, 'shop').products;
  const all = d.entries.filter((e) => filter === 'all' || e.productId === filter).slice().reverse();
  const pages = Math.max(1, Math.ceil(all.length / PAGE));
  page = Math.min(Math.max(page, 0), pages - 1);
  const slice = all.slice(page * PAGE, page * PAGE + PAGE);
  const avg = all.length ? (all.reduce((s, e) => s + e.stars, 0) / all.length).toFixed(2) : '—';
  const title = filter === 'all' ? 'Todos os feedbacks' : `Feedbacks: ${products[filter]?.name || 'produto removido'}`;
  const body = slice.length
    ? slice.map((e) => `**${ui.stars(e.stars)}** — <@${e.userId}> • ticket #${String(e.number).padStart(4, '0')}${e.productName ? ` • ${e.productName}` : ''} • ${ts(e.at, 'd')}${e.comment ? `\n> ${trunc(e.comment, 200)}` : ''}`).join('\n\n')
    : '*Nenhum feedback encontrado.*';
  const prods = Object.values(products).slice(0, 15);
  const rows = [];
  rows.push(ui.row(ui.btn('fb:list:all:0', 'Todos', { style: filter === 'all' ? 'primary' : 'secondary' }), ...prods.slice(0, 4).map((p) => ui.btn(`fb:list:${p.id}:0`, p.name, { style: filter === p.id ? 'primary' : 'secondary' }))));
  for (let k = 4; k < prods.length; k += 5) rows.push(ui.row(prods.slice(k, k + 5).map((p) => ui.btn(`fb:list:${p.id}:0`, p.name, { style: filter === p.id ? 'primary' : 'secondary' }))));
  rows.push(ui.row(ui.btn(`fb:list:${filter}:${page - 1}`, '◀', { disabled: page === 0 }), ui.btn('fb:noop', `${page + 1}/${pages}`, { disabled: true }), ui.btn(`fb:list:${filter}:${page + 1}`, '▶', { disabled: page >= pages - 1 })));
  return { ...ui.page({ title: `⭐ ${title}`, text: `**Total:** ${all.length} • **Média:** ${avg}\n\n${body}`, rows }), allowedMentions: { parse: [] } };
}

async function command(m) {
  if (!hasPerm(m.guild.id, m.member, m.author.id, 'feedbacks')) {
    return m.reply({ content: '❌ Você não tem permissão para consultar feedbacks.', allowedMentions: { repliedUser: false } }).catch(() => {});
  }
  return m.reply({ ...listPayload(m.guild, 'all', 0), allowedMentions: { repliedUser: false, parse: [] } });
}

async function handle(i) {
  const [, act, a, b, c] = i.customId.split(':');
  if (act === 'noop') return i.deferUpdate();
  if (act === 'list') {
    if (!i.guild || !hasPerm(i.guildId, i.member, i.user.id, 'feedbacks')) return i.reply({ content: '❌ Sem permissão.', flags: ui.EPH });
    return i.update(listPayload(i.guild, a, Number(b)));
  }
  // avaliação por DM: fb:r:<guildId>:<ticket>:<stars> → modal ; fb:m:... → envio
  const [gid, number, stars] = [a, b, c];
  const pending = store.get(gid, 'feedback').pending[number];
  if (act === 'r') {
    if (!pending || pending.userId !== i.user.id) return i.reply({ content: '❌ Esta avaliação não está mais disponível.' });
    return i.showModal(ui.modal(`fb:m:${gid}:${number}:${stars}`, `Sua nota: ${stars}/5`, [{ id: 'comment', label: 'Comentário (opcional)', paragraph: true, required: false, max: 1000 }]));
  }
  if (act === 'm') {
    if (!pending || pending.userId !== i.user.id) return i.reply({ content: '❌ Esta avaliação já foi enviada.' });
    const entry = { id: uid(8), number: Number(number), userId: i.user.id, stars: Number(stars), comment: i.fields.getTextInputValue('comment').trim(), productId: pending.productId, productName: pending.productName, at: Date.now() };
    store.update(gid, 'feedback', (d) => {
      delete d.pending[number];
      d.entries.push(entry);
    });
    const guild = await i.client.guilds.fetch(gid).catch(() => null);
    if (guild) {
      await publishEntry(guild, entry);
      await log(guild, 'feedbacks', { title: 'Feedback recebido', description: `<@${i.user.id}> avaliou o ticket #${number} com ${entry.stars}/5.${entry.comment ? `\n> ${trunc(entry.comment, 300)}` : ''}` });
    }
    return i.update(ui.page({ title: '💙 Obrigado pela avaliação!', text: `Você deu **${entry.stars}/5**. Seu feedback foi registrado.`, color: ui.COLORS.ok }));
  }
}

module.exports = { sendRequest, command, handle, listPayload };
