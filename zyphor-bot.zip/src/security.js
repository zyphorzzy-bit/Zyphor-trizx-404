const store = require('./storage');
const moderation = require('./moderation');
const { log } = require('./logs');
const { uid, trunc } = require('./util');
const { OWNER_ID } = require('./constants');

const BASE = { enabled: false, limit: 5, windowSec: 10, action: 'delete', timeoutMin: 10, exemptRoles: [], exemptChannels: [] };
const RULES = {
  flood: { name: 'Anti-Flood', desc: 'Muitas mensagens em pouco tempo.', kind: 'msg', d: { limit: 7, windowSec: 5, action: 'timeout', timeoutMin: 5 }, fields: ['limit', 'windowSec', 'timeoutMin'] },
  spam: { name: 'Anti-Spam', desc: 'Mensagens idênticas repetidas.', kind: 'msg', d: { limit: 4, windowSec: 30, action: 'timeout', timeoutMin: 10 }, fields: ['limit', 'windowSec', 'timeoutMin'] },
  link: { name: 'Anti-Link', desc: 'Links fora da lista de domínios permitidos.', kind: 'msg', d: { action: 'delete', timeoutMin: 10, allowedDomains: [] }, fields: ['timeoutMin'] },
  mention: { name: 'Anti-Mention', desc: 'Menções em excesso em uma mensagem.', kind: 'msg', d: { limit: 5, action: 'timeout', timeoutMin: 10 }, fields: ['limit', 'timeoutMin'] },
  phishing: { name: 'Anti-Phishing', desc: 'Links de golpe/phishing (lista + heurísticas).', kind: 'msg', d: { action: 'timeout', timeoutMin: 60, blockedDomains: [] }, fields: ['timeoutMin'] },
  raid: { name: 'Anti-Raid', desc: 'Muitas entradas em pouco tempo.', kind: 'join', d: { limit: 8, windowSec: 30, action: 'kick', timeoutMin: 60 }, fields: ['limit', 'windowSec', 'timeoutMin'] },
  bot: { name: 'Anti-Bot', desc: 'Bots adicionados sem autorização.', kind: 'join', d: { action: 'kick', timeoutMin: 60, allowedBots: [] }, fields: ['timeoutMin'] },
  fake: { name: 'Anti-Fake', desc: 'Contas muito novas (ou sem avatar).', kind: 'join', d: { minAgeDays: 7, noAvatar: false, action: 'kick', timeoutMin: 60 }, fields: ['minAgeDays', 'timeoutMin'] },
};
const MSG_ACTIONS = ['delete', 'warn', 'timeout', 'kick', 'ban'];
const JOIN_ACTIONS = ['warn', 'timeout', 'kick', 'ban'];
const FIELD_LABELS = { limit: 'Limite (quantidade)', windowSec: 'Tempo de detecção (segundos)', timeoutMin: 'Duração do timeout (minutos)', minAgeDays: 'Idade mínima da conta (dias)' };

function rule(gid, key) {
  const saved = store.get(gid, 'security').rules[key] || {};
  return { ...BASE, ...structuredClone(RULES[key].d), ...saved };
}
function setRule(gid, key, patch) {
  store.update(gid, 'security', (d) => {
    d.rules[key] = { ...(d.rules[key] || {}), ...patch };
  });
}

const buckets = new Map();
function hit(key, windowMs, entry) {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter((e) => now - e.t < windowMs);
  arr.push({ t: now, ...entry });
  buckets.set(key, arr);
  return arr;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of buckets) if (!v.length || now - v[v.length - 1].t > 300000) buckets.delete(k);
}, 60000).unref();

function exempt(r, member, channelId) {
  if (member && (member.id === OWNER_ID || member.id === member.guild.ownerId)) return true;
  if (member && r.exemptRoles.some((id) => member.roles.cache.has(id))) return true;
  if (channelId && r.exemptChannels.includes(channelId)) return true;
  return false;
}

const URL_RE = /(?:https?:\/\/|www\.)[^\s<>()]+|\b[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|net|org|gg|io|ru|xyz|top|site|club|info|link|me|co|app|gift|click)\b[^\s<>()]*/gi;
function hostsOf(text) {
  const out = [];
  for (const m of text.match(URL_RE) || []) {
    try {
      out.push(new URL(/^https?:\/\//i.test(m) ? m : `http://${m}`).hostname.toLowerCase().replace(/^www\./, ''));
    } catch {}
  }
  return out;
}
const hostMatches = (host, list) => list.some((d) => host === d || host.endsWith('.' + d));
const TRUSTED = ['discord.com', 'discordapp.com', 'discord.gg', 'discord.media', 'discordapp.net', 'steamcommunity.com', 'steampowered.com'];

function isPhishing(text, blocked) {
  const hosts = hostsOf(text);
  for (const h of hosts) {
    if (hostMatches(h, blocked)) return `domínio bloqueado (${h})`;
    if (hostMatches(h, TRUSTED)) continue;
    if (h.startsWith('xn--') || h.includes('.xn--')) return `domínio punycode suspeito (${h})`;
    if (/(disc[o0]r[dcl]|d[i1l]scord|discrod|dlscord|steamcomm?un[i1]ty|steamcornmunity|nitro|gift)/i.test(h)) return `domínio imitando Discord/Steam (${h})`;
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return `link para IP (${h})`;
  }
  if (hosts.length && /(free|gr[aá]tis|gratuito).{0,25}nitro|nitro.{0,25}(free|gr[aá]tis)|airdrop.{0,20}(discord|steam)/i.test(text)) return 'texto típico de golpe de Nitro/airdrop';
  return null;
}

async function record(guild, key, member, userId, reason, action, extra = {}) {
  const ev = { id: uid(8), rule: key, userId, reason, action, at: Date.now(), ...extra };
  store.update(guild.id, 'security', (d) => {
    d.events.push(ev);
    if (d.events.length > 1000) d.events.splice(0, d.events.length - 1000);
  });
  await log(guild, 'security', { title: `${RULES[key].name} acionado`, description: `**Usuário:** <@${userId}>\n**Motivo:** ${reason}\n**Ação:** ${action}${extra.channelId ? `\n**Canal:** <#${extra.channelId}>` : ''}${extra.content ? `\n**Conteúdo:** ${trunc(extra.content, 300)}` : ''}` });
}

async function punish(guild, key, r, userId, reason, member) {
  if (r.action === 'delete') return 'mensagem excluída';
  const type = r.action;
  const res = await moderation.apply(guild, { targetId: userId, moderator: null, type, reason: `[${RULES[key].name}] ${reason}`, durationMs: r.timeoutMin * 60000, source: `security:${key}` });
  return res.ok ? type : `${type} falhou: ${res.error}`;
}

async function onMessage(m) {
  if (!m.guild || m.author.bot || !m.member) return false;
  const gid = m.guild.id;
  const text = m.content || '';
  let hitRule = null;

  const check = (key, fn) => {
    if (hitRule) return;
    const r = rule(gid, key);
    if (!r.enabled || exempt(r, m.member, m.channelId)) return;
    const reason = fn(r);
    if (reason) hitRule = { key, r, reason };
  };

  check('flood', (r) => {
    const arr = hit(`flood:${gid}:${m.author.id}`, r.windowSec * 1000, { id: m.id, ch: m.channelId });
    if (arr.length >= r.limit) {
      hitRule = null;
      m._floodMsgs = arr;
      buckets.delete(`flood:${gid}:${m.author.id}`);
      return `${arr.length} mensagens em ${r.windowSec}s`;
    }
  });
  check('spam', (r) => {
    if (!text.trim()) return;
    const arr = hit(`spam:${gid}:${m.author.id}:${text.toLowerCase().slice(0, 200)}`, r.windowSec * 1000, { id: m.id, ch: m.channelId });
    if (arr.length >= r.limit) {
      m._floodMsgs = arr;
      buckets.delete(`spam:${gid}:${m.author.id}:${text.toLowerCase().slice(0, 200)}`);
      return `mensagem repetida ${arr.length}x em ${r.windowSec}s`;
    }
  });
  check('mention', (r) => {
    const n = m.mentions.users.size + m.mentions.roles.size + (m.mentions.everyone ? 1 : 0);
    return n >= r.limit ? `${n} menções em uma mensagem` : null;
  });
  check('phishing', (r) => isPhishing(text, r.blockedDomains));
  check('link', (r) => {
    const bad = hostsOf(text).find((h) => !hostMatches(h, r.allowedDomains));
    return bad ? `link não permitido (${bad})` : null;
  });

  if (!hitRule) return false;
  const { key, r, reason } = hitRule;
  // apaga a mensagem que disparou (e as do flood/spam, quando houver)
  const ids = m._floodMsgs ? m._floodMsgs : [{ id: m.id, ch: m.channelId }];
  for (const e of ids) {
    const ch = m.guild.channels.cache.get(e.ch);
    await ch?.messages?.delete(e.id).catch(() => {});
  }
  const result = await punish(m.guild, key, r, m.author.id, reason, m.member);
  await record(m.guild, key, m.member, m.author.id, reason, result, { channelId: m.channelId, content: text });
  return true;
}

// ---- entradas (raid / bot / fake) ----
async function onMemberAdd(member) {
  const guild = member.guild;
  const gid = guild.id;
  if (member.id === guild.client.user.id) return;

  const bot = rule(gid, 'bot');
  if (member.user.bot && bot.enabled && !bot.allowedBots.includes(member.id)) {
    const res = await punish(guild, 'bot', { ...bot, action: bot.action === 'warn' ? 'warn' : bot.action }, member.id, 'bot não autorizado', member);
    await record(guild, 'bot', member, member.id, 'bot não autorizado adicionado', res);
    return;
  }
  if (member.user.bot) return;

  const fake = rule(gid, 'fake');
  if (fake.enabled && !exempt(fake, member, null)) {
    const ageDays = (Date.now() - member.user.createdTimestamp) / 86400000;
    let reason = null;
    if (ageDays < fake.minAgeDays) reason = `conta com ${ageDays.toFixed(1)} dia(s) (mínimo ${fake.minAgeDays})`;
    else if (fake.noAvatar && !member.user.avatar) reason = 'conta sem avatar';
    if (reason) {
      const res = await punish(guild, 'fake', fake, member.id, reason, member);
      await record(guild, 'fake', member, member.id, reason, res);
      return;
    }
  }

  const raid = rule(gid, 'raid');
  if (raid.enabled) {
    const key = `raid:${gid}`;
    const arr = hit(key, raid.windowSec * 1000, { uid: member.id });
    const flagged = buckets.get(`raidmode:${gid}`);
    if (arr.length >= raid.limit || (flagged && Date.now() < flagged)) {
      const victims = arr.length >= raid.limit && !(flagged && Date.now() < flagged) ? arr.map((e) => e.uid) : [member.id];
      buckets.set(`raidmode:${gid}`, Date.now() + raid.windowSec * 1000);
      if (victims.length > 1) await log(guild, 'security', { title: '🚨 Raid detectado', description: `${victims.length} entradas em ${raid.windowSec}s. Aplicando **${raid.action}**.` });
      for (const id of victims) {
        const res = await punish(guild, 'raid', raid, id, `entrada em massa (${arr.length} em ${raid.windowSec}s)`, null);
        await record(guild, 'raid', null, id, `entrada em massa (${arr.length} em ${raid.windowSec}s)`, res);
      }
    }
  }
}

module.exports = { RULES, BASE, MSG_ACTIONS, JOIN_ACTIONS, FIELD_LABELS, rule, setRule, onMessage, onMemberAdd };
