require('dotenv').config();
const { Client, GatewayIntentBits, Partials, MessageFlags, Events } = require('discord.js');
const store = require('./storage');
const config = require('./config');
const templates = require('./templates');
const tickets = require('./tickets');
const feedback = require('./feedback');
const security = require('./security');
const honeypot = require('./honeypot');
const welcome = require('./welcome');
const rules = require('./rules');
const ai = require('./ai');
require('./announcements'); // registra o publicador de avisos

if (!process.env.DISCORD_TOKEN) {
  console.error('DISCORD_TOKEN não definido. Configure nos Secrets/variáveis de ambiente.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // privilegiado
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // privilegiado
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

const COMMANDS = [{ name: 'config', description: 'Painel central de configuração do ZYPhor Bot' }];
async function registerCommands(guild) {
  await guild.commands.set(COMMANDS).catch((e) => console.error(`[cmd] ${guild.name}:`, e.message));
}

client.once(Events.ClientReady, async (c) => {
  console.log(`ZYPhor Bot online como ${c.user.tag} em ${c.guilds.cache.size} servidor(es).`);
  for (const g of c.guilds.cache.values()) await registerCommands(g);
  try { store.backupNow(); } catch (e) { console.error('[backup] inicial:', e.message); }
  const hours = Number(process.env.BACKUP_INTERVAL_HOURS || 6);
  setInterval(() => { try { store.backupNow(); } catch (e) { console.error('[backup]', e.message); } }, hours * 3600000).unref();
});
client.on(Events.GuildCreate, registerCommands);

const ROUTES = {
  cfg: config.handle,
  tpl: templates.handle,
  btn: templates.handleButton,
  tk: tickets.handle,
  fb: feedback.handle,
  ai: ai.handle,
  rules: (i) => rules.handle(i, config.rulesPage),
};

client.on(Events.InteractionCreate, async (i) => {
  try {
    if (i.isChatInputCommand()) {
      if (i.commandName === 'config') return await config.open(i);
      return;
    }
    const id = i.customId;
    if (!id) return;
    const fn = ROUTES[id.split(':')[0]];
    if (fn) await fn(i);
  } catch (e) {
    console.error('[interaction]', i.customId || i.commandName, e);
    const msg = { content: '❌ Ocorreu um erro ao processar essa ação. Tente novamente.', flags: MessageFlags.Ephemeral };
    try {
      if (i.deferred || i.replied) await i.followUp(msg);
      else await i.reply(msg);
    } catch {}
  }
});

client.on(Events.MessageCreate, async (m) => {
  try {
    if (m.author.bot || m.webhookId || !m.guild) return;
    if (/^z!feedbacks\b/i.test(m.content)) return await feedback.command(m);
    if (await honeypot.onMessage(m)) return;
    if (await security.onMessage(m)) return;
    await ai.onMessage(m);
  } catch (e) {
    console.error('[messageCreate]', e);
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  try {
    await security.onMemberAdd(member);
    await welcome.onJoin(member);
  } catch (e) { console.error('[memberAdd]', e); }
});
client.on(Events.GuildMemberRemove, (member) => welcome.onLeave(member).catch((e) => console.error('[memberRemove]', e)));
client.on(Events.ChannelDelete, (ch) => tickets.onChannelDelete(ch).catch(() => {}));
client.on(Events.ThreadDelete, (th) => tickets.onChannelDelete(th).catch(() => {}));
client.on(Events.Error, (e) => console.error('[client]', e));
process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e));

client.login(process.env.DISCORD_TOKEN);
