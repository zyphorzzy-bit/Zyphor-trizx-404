const { EmbedBuilder } = require('discord.js');
const store = require('./storage');
const { uid, trunc } = require('./util');

const COLORS = { tickets: 0x5865f2, transcripts: 0x99aab5, feedbacks: 0xfee75c, shop: 0x57f287, moderation: 0xed4245, security: 0xe67e22, honeypot: 0x9b59b6, admin: 0x3498db };

// Grava o registro em JSON (logs.json) e envia ao canal configurado, quando houver.
async function log(guild, kind, { title, description = '', fields = [], files = [], color } = {}) {
  try {
    store.update(guild.id, 'logs', (d) => {
      d.entries.push({ id: uid(8), kind, at: Date.now(), title, description: trunc(description, 1500) });
      if (d.entries.length > 3000) d.entries.splice(0, d.entries.length - 3000);
    });
  } catch (e) {
    console.error('[logs] falha ao gravar:', e.message);
  }
  const chId = store.get(guild.id, 'core').logs[kind];
  if (!chId) return;
  const ch = await guild.channels.fetch(chId).catch(() => null);
  if (!ch?.isTextBased()) return;
  const e = new EmbedBuilder().setColor(color || COLORS[kind] || 0x5865f2).setTitle(trunc(title, 256)).setTimestamp();
  if (description) e.setDescription(trunc(description, 4000));
  if (fields.length) e.addFields(fields.slice(0, 25).map((f) => ({ name: trunc(f.name, 256), value: trunc(f.value || '—', 1024), inline: !!f.inline })));
  await ch.send({ embeds: [e], files, allowedMentions: { parse: [] } }).catch((err) => console.error('[logs] envio falhou:', err.message));
}

function recent(guildId, kind, sinceMs) {
  return store.get(guildId, 'logs').entries.filter((e) => (!kind || e.kind === kind) && e.at >= sinceMs);
}

module.exports = { log, recent };
