const store = require('./storage');
const templates = require('./templates');
const moderation = require('./moderation');
const ui = require('./ui');
const { log } = require('./logs');
const { uid, trunc } = require('./util');
const { OWNER_ID } = require('./constants');

const ACTIONS = { delete: 'Apenas excluir mensagem', warn: 'Advertência', timeout: 'Castigo (timeout)', kick: 'Expulsão', ban: 'Banimento' };
const REF = 'honeypot.warn';

async function onMessage(m) {
  if (!m.guild || m.author.bot || m.webhookId) return false;
  const cfg = store.get(m.guild.id, 'honeypot');
  if (!cfg.enabled || !cfg.channelId || m.channelId !== cfg.channelId) return false;
  const member = m.member || (await m.guild.members.fetch(m.author.id).catch(() => null));
  if (member && (member.id === OWNER_ID || member.id === m.guild.ownerId || cfg.exemptRoles.some((r) => member.roles.cache.has(r)))) return false;

  const content = m.content ? m.content : m.attachments.size ? `[anexos: ${[...m.attachments.values()].map((a) => a.name).join(', ')}]` : '(conteúdo indisponível — ative o Message Content Intent)';
  await m.delete().catch(() => {});
  let result = 'mensagem excluída';
  if (cfg.action !== 'delete') {
    const res = await moderation.apply(m.guild, {
      targetId: m.author.id,
      moderator: null,
      type: cfg.action,
      reason: 'Honeypot: enviou mensagem no canal armadilha',
      durationMs: cfg.days * 86400000,
      source: 'honeypot',
    });
    result = res.ok ? cfg.action : `${cfg.action} falhou: ${res.error}`;
  }
  const ev = { id: uid(8), userId: m.author.id, channelId: m.channelId, content: trunc(content, 1500), at: Date.now(), action: result };
  store.update(m.guild.id, 'honeypot', (d) => {
    d.events.push(ev);
    if (d.events.length > 1000) d.events.splice(0, d.events.length - 1000);
  });
  await log(m.guild, 'honeypot', { title: '🍯 Honeypot acionado', description: `**Usuário:** <@${m.author.id}> (${m.author.id})\n**Canal:** <#${m.channelId}>\n**Ação:** ${result}\n**Conteúdo:** ${trunc(content, 800)}` });
  return true;
}

// Publica (ou atualiza) a mensagem de aviso persistente
async function publish(i) {
  const cfg = store.get(i.guildId, 'honeypot');
  const chId = cfg.publishChannelId || cfg.channelId;
  if (!chId) throw new Error('Escolha o canal do honeypot ou o canal de publicação primeiro.');
  const ch = await i.guild.channels.fetch(chId).catch(() => null);
  if (!ch?.isTextBased()) throw new Error('Canal de publicação inválido.');
  const payload = { ...ui.renderTemplate(templates.get(i.guildId, REF), templates.varsFor(i.user, i.guild), REF), allowedMentions: { parse: [] } };
  let msg = null;
  if (cfg.messageId && cfg.messageChannelId === ch.id) msg = await ch.messages.fetch(cfg.messageId).catch(() => null);
  if (msg) await msg.edit(payload);
  else msg = await ch.send(payload);
  store.update(i.guildId, 'honeypot', (d) => {
    d.messageId = msg.id;
    d.messageChannelId = ch.id;
  });
  return `✅ Aviso do honeypot publicado em <#${ch.id}>.`;
}

templates.registerKind('honeypot', { back: () => 'cfg:honeypot', publish, publishLabel: 'Publicar aviso' });

module.exports = { onMessage, ACTIONS };
