# ZYPhor Bot

Bot Discord em **Node.js + discord.js**, dados somente em **arquivos JSON** (sem banco de dados), painéis em **Components V2** (Embed opcional onde faz sentido).

## Comandos
- `/config` — painel central (tudo por botões, menus, seletores de canal/cargo/usuário e modais; sem digitar IDs).
- `z!feedbacks` — consulta de feedbacks (equipe com permissão `feedbacks`), com botões por produto.

## Instalação
1. `npm install`
2. Copie `.env.example` para `.env` (ou use os **Secrets** da hospedagem) e preencha `DISCORD_TOKEN`.
3. No Developer Portal ative os intents privilegiados **Server Members** e **Message Content**.
4. Convide o bot com permissões: Administrator ou, no mínimo, Gerenciar Canais/Cargos/Mensagens/Tópicos, Expulsar, Banir, Moderar Membros, Ver Log de Auditoria, Enviar Mensagens/Embeds/Anexos.
5. `npm start`. Use um **volume persistente** para `DATA_DIR` (padrão `./data`).

## Primeiros passos no servidor
`/config` → Permissões e canais de log → autorize cargos (o proprietário principal já tem acesso total) → Tickets (categorias, painel, publicar) → Loja → Segurança etc.

## Armazenamento
`data/guilds/<guildId>/<modulo>.json` (core, tickets, shop, feedback, moderation, security, honeypot, welcome, announcements, rules, ai, templates, logs) e `transcripts/<n>.html`. Gravação atômica (arquivo temporário + rename + `.bak`), recuperação automática de arquivo corrompido, backups em `data/backups/` (a cada `BACKUP_INTERVAL_HOURS`, mantendo `BACKUP_KEEP`) e restauração pelo `/config` → Backup.

## IA (opcional)
Defina `ANTHROPIC_API_KEY` (ou `AI_PROVIDER=openai` + `AI_API_KEY`/`AI_BASE_URL`) apenas nos Secrets. Modos por módulo: desativada, manual, automática, assistente. A IA nunca bane, expulsa nem aplica timeout; em segurança, no máximo apaga a mensagem e avisa a equipe.

## Observações importantes
- **Pagamento** nunca é confirmado automaticamente: a equipe confirma e usa **Entregar compra** (exige *Gerenciar Cargos* e cargo do bot acima dos cargos entregues).
- **Threads privadas**: o Discord não permite adicionar cargos a tópicos privados; a equipe é marcada na abertura e quem tem *Gerenciar Tópicos* enxerga todos. O cliente não pode convidar ninguém.
- **Honeypot**: o canal precisa permitir que membros enviem mensagens. O conteúdo só é registrado com o Message Content Intent ativo.
- Cada ticket aberto por usuário: um por vez. Tickets fechados são definitivos (sem reabrir).
- Sem painel/cards de vendas: o cliente escolhe o produto dentro de uma categoria do tipo **Loja** de um painel de tickets (mensagens privadas/efêmeras).

## Teste rápido
`npm run check` — teste de fumaça do armazenamento (criação, recuperação, backup/restauração).
