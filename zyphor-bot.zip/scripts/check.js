// Teste de fumaça do armazenamento JSON (não precisa de token nem de rede).
process.env.DATA_DIR = require('path').join(require('os').tmpdir(), 'zyphor-check-' + Date.now());
const assert = require('assert');
const fs = require('fs');
const store = require('../src/storage');
const G = '123456789012345678';

let d = store.get(G, 'core');
assert.deepStrictEqual(d.permissions, {});
store.update(G, 'core', (x) => { x.permissions['1'] = ['config']; x.logs.tickets = '9'; });
store.update(G, 'tickets', (x) => { x.counter = 5; });
assert.ok(fs.existsSync(`${store.DATA_DIR}/guilds/${G}/core.json`), 'arquivo criado automaticamente');

// recarrega do disco (simula reinício)
for (const f of fs.readdirSync(`${store.DATA_DIR}/guilds/${G}`)) void f;
delete require.cache[require.resolve('../src/storage')];
const s2 = require('../src/storage');
assert.strictEqual(s2.get(G, 'core').permissions['1'][0], 'config');
assert.strictEqual(s2.get(G, 'tickets').counter, 5);
assert.strictEqual(s2.get(G, 'tickets').settings.mode, 'channel', 'defaults mesclados');

// arquivo corrompido -> recupera do .bak
store.update(G, 'core', (x) => { x.logs.admin = '7'; });
fs.writeFileSync(`${store.DATA_DIR}/guilds/${G}/core.json`, '{corrompido');
delete require.cache[require.resolve('../src/storage')];
const s3 = require('../src/storage');
assert.ok(s3.get(G, 'core').permissions['1'], 'recuperou do .bak');

// backup + restauração
const stamp = s3.backupNow();
assert.ok(s3.backupHasGuild(stamp, G));
s3.update(G, 'tickets', (x) => { x.counter = 99; });
s3.restoreGuild(stamp, G);
assert.strictEqual(s3.get(G, 'tickets').counter, 5, 'restaurou backup');
assert.throws(() => s3.get('../x', 'core'));
console.log('OK: storage, defaults, recuperação, backup e restauração.');
fs.rmSync(store.DATA_DIR, { recursive: true, force: true });
