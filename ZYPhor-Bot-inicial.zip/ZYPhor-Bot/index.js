const path = require("node:path");
const { Client, GatewayIntentBits, Partials, REST, Routes } = require("discord.js");
const configCommand = require("./src/commands/config");
const { handleInteraction } = require("./src/events/interactionCreate");
const { handleMessage } = require("./src/events/messageCreate");
const { ensureDataFolders } = require("./src/storage/jsonStore");

const BOT_OWNER_ID = "1533306874513068093";

if (!process.env.DISCORD_TOKEN) {
  console.error("ERRO: configure DISCORD_TOKEN nos Secrets/variáveis da hospedagem.");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration
  ],
  partials: [Partials.Message, Partials.Channel]
});

client.botOwnerId = BOT_OWNER_ID;
client.isBotOwner = (userId) => userId === BOT_OWNER_ID;
client.commands = new Map([[configCommand.data.name, configCommand]]);

ensureDataFolders();

client.once("ready", async () => {
  console.log(`ZYPhor Bot conectado como ${client.user.tag}`);
  console.log(`Proprietário principal: ${BOT_OWNER_ID}`);
  console.log("Armazenamento: arquivos JSON (sem banco de dados)");

  try {
    const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
    await rest.put(Routes.applicationCommands(client.user.id), {
      body: [configCommand.data.toJSON()]
    });
    console.log("Comando /config registrado globalmente.");
  } catch (error) {
    console.error("Não foi possível registrar /config:", error);
  }
});

client.on("interactionCreate", (interaction) => {
  handleInteraction(client, interaction).catch(console.error);
});

client.on("messageCreate", (message) => {
  handleMessage(client, message).catch(console.error);
});

client.login(process.env.DISCORD_TOKEN);
