# ZYPhor Bot — pacote inicial

Esta é a base funcional do projeto. Ela inclui:
- conexão com Discord usando discord.js;
- registro do único comando slash `/config`;
- comando por prefixo `z!feedbacks`;
- autorização do proprietário principal;
- seleção e salvamento dos canais de logs e feedbacks;
- armazenamento em arquivos JSON, sem banco de dados.

## Requisitos
- Node.js 20 ou superior.
- Aplicação e bot criados no Discord Developer Portal.
- Bot convidado ao servidor com permissões adequadas.

## Segredos da hospedagem
Configure estas variáveis no painel de Secrets/Environment Variables da hospedagem:
- `DISCORD_TOKEN`: token do bot.
- Não compartilhe o token no chat nem o coloque em arquivos públicos.

O ID do aplicativo é obtido do próprio bot quando ele inicia; não é necessário configurar `CLIENT_ID`.

## Instalação
Na pasta do projeto, execute:

```bash
npm install
npm start
```

No Discord Developer Portal, habilite os intents privilegiados **Server Members Intent** e **Message Content Intent** se for usar os recursos correspondentes. Para este pacote, o Message Content Intent é necessário para reconhecer `z!feedbacks`.

## Como usar
- `/config`: abre o painel inicial. O proprietário principal ou um administrador do servidor pode selecionar os canais de logs e feedbacks.
- `z!feedbacks`: mostra os últimos feedbacks salvos em `data/feedbacks/ID_DO_SERVIDOR.json`.

## Importante sobre o escopo
Este ZIP é a primeira base funcional, não a versão final com todos os módulos planejados. Tickets completos, entrega de cargos, moderação, Honeypot, anti-spam, IA, boas-vindas e fluxo de compra ainda precisam ser implementados e testados antes de serem anunciados como funcionais.

## Persistência
Os JSON ficam dentro da pasta `data/`. Use uma hospedagem que preserve arquivos entre reinicializações e faça backups. Se a hospedagem apagar o disco local ao reiniciar, os dados podem ser perdidos.

## Segurança
Nunca publique o token do bot. Se ele vazar, regenere-o no Discord Developer Portal.
