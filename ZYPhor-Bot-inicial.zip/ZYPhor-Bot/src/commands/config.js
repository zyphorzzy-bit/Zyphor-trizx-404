const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
  ChannelType
} = require("discord.js");
const { readJson, writeJson } = require("../storage/jsonStore");
const { canManageConfig } = require("../utils/permissions");

function makePanel(guildId, config) {
  const embed = new EmbedBuilder()
    .setColor(0x252525)
    .setTitle("ZYPhor Bot • Configurações")
    .setDescription(
      "Painel administrativo inicial. As escolhas são salvas em arquivos JSON.\n\n" +
      "**Canais configurados**\n" +
      `• Logs: ${config.channels.logs ? `<#${config.channels.logs}>` : "Não definido"}\n` +
      `• Feedbacks: ${config.channels.feedbacks ? `<#${config.channels.feedbacks}>` : "Não definido"}\n\n` +
      "Os módulos avançados serão conectados ao painel nas próximas etapas."
    )
    .setFooter({ text: "ZYPhor Bot • Configuração persistente em JSON" });

  const logs = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId("zyphor_config_logs")
      .setPlaceholder("Selecionar canal de registros")
      .setChannelTypes(ChannelType.GuildText)
      .setMinValues(1)
      .setMaxValues(1)
  );

  const feedbacks = new ActionRowBuilder().addComponents(
    new ChannelSelectMenuBuilder()
      .setCustomId("zyphor_config_feedbacks")
      .setPlaceholder("Selecionar canal de feedbacks")
      .setChannelTypes(ChannelType.GuildText)
      .setMinValues(1)
      .setMaxValues(1)
  );

  return { embeds: [embed], components: [logs, feedbacks], ephemeral: true };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("config")
    .setDescription("Abrir o painel de configuração do ZYPhor Bot"),

  async execute(interaction, client) {
    if (!interaction.guild) {
      return interaction.reply({ content: "Use este comando dentro de um servidor.", ephemeral: true });
    }

    if (!canManageConfig(interaction, client)) {
      return interaction.reply({ content: "Você não tem permissão para configurar o ZYPhor Bot.", ephemeral: true });
    }

    const config = await readJson(`configs/${interaction.guildId}.json`, {
      channels: { logs: null, feedbacks: null }
    });

    return interaction.reply(makePanel(interaction.guildId, config));
  },

  async updateChannel(interaction, key) {
    const config = await readJson(`configs/${interaction.guildId}.json`, {
      channels: { logs: null, feedbacks: null }
    });
    config.channels ??= {};
    config.channels[key] = interaction.values[0];
    await writeJson(`configs/${interaction.guildId}.json`, config);
    return interaction.reply({
      content: `Canal de ${key === "logs" ? "registros" : "feedbacks"} salvo com sucesso.`,
      ephemeral: true
    });
  }
};
