const fs = require("node:fs/promises");
const path = require("node:path");

const DATA_DIR = path.resolve(__dirname, "../../data");

const folders = [
  "configs", "tickets", "products", "feedbacks",
  "moderation", "security", "logs"
];

function safePath(relativePath) {
  const fullPath = path.resolve(DATA_DIR, relativePath);
  if (!fullPath.startsWith(DATA_DIR + path.sep)) {
    throw new Error("Caminho de armazenamento inválido.");
  }
  return fullPath;
}

async function ensureDataFolders() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await Promise.all(folders.map((folder) =>
    fs.mkdir(path.join(DATA_DIR, folder), { recursive: true })
  ));
}

async function readJson(relativePath, fallback) {
  const filePath = safePath(relativePath);
  try {
    const content = await fs.readFile(filePath, "utf8");
    return JSON.parse(content);
  } catch (error) {
    if (error.code === "ENOENT") return fallback;
    console.error(`Erro lendo ${relativePath}:`, error);
    return fallback;
  }
}

async function writeJson(relativePath, value) {
  const filePath = safePath(relativePath);
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const temporaryPath = `${filePath}.tmp`;
  await fs.writeFile(temporaryPath, JSON.stringify(value, null, 2), "utf8");
  await fs.rename(temporaryPath, filePath);
}

module.exports = { ensureDataFolders, readJson, writeJson };
