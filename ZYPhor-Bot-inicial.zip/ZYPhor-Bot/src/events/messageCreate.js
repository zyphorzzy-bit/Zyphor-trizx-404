const { EmbedBuilder } = require("discord.js");
const { readJson } = require("../storage/jsonStore");
const { canUseFeedbackCommand } = require("../utils/permissions");

async function handleMessage(client, message) {
  if (message.author.bot || !message.guild) return;
  if (message.content.trim().toLowerCase() !== "z!feedbacks") return;

  if (!canUseFeedbackCommand(message, client)) {
    await message.reply("Você não tem permissão para consultar os feedbacks.");
    return;
  }

  const feedbacks = await readJson(`feedbacks/${message.guildId}.json`, []);
  if (!Array.isArray(feedbacks) || feedbacks.length === 0) {
    await message.reply("Ainda não há feedbacks registrados neste servidor.");
    return;
  }

  const recent = feedbacks.slice(-10).reverse();
  const description = recent.map((item, index) => {
    const stars = "⭐".repeat(Math.max(1, Math.min(5, Number(item.rating) || 1)));
    const comment = item.comment ? ` — ${String(item.comment).slice(0, 180)}` : "";
    return `**${index + 1}.** ${stars}${comment}`;
  }).join("\n");

  const embed = new EmbedBuilder()
    .setColor(0x777777)
    .setTitle("ZYPhor • Feedbacks recentes")
    .setDescription(description)
    .setFooter({ text: `Mostrando ${recent.length} de ${feedbacks.length} feedback(s)` });

  await message.reply({ embeds: [embed] });
}

module.exports = { handleMessage };
