const configCommand = require("../commands/config");

async function handleInteraction(client, interaction) {
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (command) await command.execute(interaction, client);
    return;
  }

  if (interaction.isChannelSelectMenu()) {
    if (!interaction.customId.startsWith("zyphor_config_")) return;

    const { canManageConfig } = require("../utils/permissions");
    if (!canManageConfig(interaction, client)) {
      return interaction.reply({ content: "Você não tem permissão para alterar esta configuração.", ephemeral: true });
    }

    const key = interaction.customId.replace("zyphor_config_", "");
    if (!["logs", "feedbacks"].includes(key)) return;
    await configCommand.updateChannel(interaction, key);
  }
}

module.exports = { handleInteraction };
