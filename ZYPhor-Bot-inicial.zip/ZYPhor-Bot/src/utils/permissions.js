const BOT_OWNER_ID = "1533306874513068093";

function isBotOwner(userId) {
  return userId === BOT_OWNER_ID;
}

function canManageConfig(interaction, client) {
  if (isBotOwner(interaction.user.id)) return true;
  return Boolean(interaction.memberPermissions?.has("Administrator"));
}

function canUseFeedbackCommand(message, client) {
  if (isBotOwner(message.author.id)) return true;
  return Boolean(message.member?.permissions?.has("Administrator"));
}

module.exports = {
  BOT_OWNER_ID,
  isBotOwner,
  canManageConfig,
  canUseFeedbackCommand
};
