const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { DISCORD_TOKEN } = require('./src/config/env');
const { registerReady } = require('./src/events/ready');
const { registerInteractionCreate } = require('./src/events/interactionCreate');

if (!DISCORD_TOKEN) {
  console.error('ERRO: configure DISCORD_TOKEN no ambiente da hospedagem.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration
  ],
  partials: [Partials.Channel, Partials.Message, Partials.GuildMember, Partials.User]
});

registerReady(client);
registerInteractionCreate(client);

process.on('unhandledRejection', error => {
  console.error('[unhandledRejection]', error);
});
process.on('uncaughtException', error => {
  console.error('[uncaughtException]', error);
});

client.login(DISCORD_TOKEN).catch(error => {
  console.error('Não foi possível conectar ao Discord. Confira o token e as permissões.', error);
  process.exit(1);
});
