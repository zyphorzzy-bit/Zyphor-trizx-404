const { REST, Routes, SlashCommandBuilder } = require('discord.js');
const { DISCORD_TOKEN, CLIENT_ID } = require('./src/config/env');

if (!DISCORD_TOKEN || !CLIENT_ID) {
  console.error('Configure DISCORD_TOKEN e CLIENT_ID no ambiente antes de registrar os comandos.');
  process.exit(1);
}

const commands = [
  new SlashCommandBuilder().setName('ping').setDescription('Verifica se o Zyphor Bot está respondendo.'),
  new SlashCommandBuilder().setName('config').setDescription('Abre o painel de configuração do Zyphor Bot.')
];

const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);

(async () => {
  try {
    console.log('Registrando comandos slash...');
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands.map(command => command.toJSON()) });
    console.log('Comandos registrados.');
  } catch (error) {
    console.error('Falha ao registrar comandos:', error);
    process.exitCode = 1;
  }
})();
