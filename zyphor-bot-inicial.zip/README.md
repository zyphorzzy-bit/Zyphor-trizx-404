# Zyphor Bot

Base inicial em JavaScript + Discord.js para o bot oficial Zyphor.

## Requisitos
- Node.js 20 ou superior
- Aplicação/bot criado no Discord Developer Portal

## Instalação local
1. Baixe/extrai o ZIP.
2. Execute `npm install`.
3. Copie `.env.example` para `.env` e preencha `DISCORD_TOKEN` e `CLIENT_ID`.
4. Execute `npm start`.

Não envie o token real ao GitHub nem compartilhe com outras pessoas.

## Comandos slash
- `/config` — abre um painel inicial com estado dos módulos.
- `/ping` — testa a conexão.

Para registrar comandos globalmente, defina `CLIENT_ID` e `DISCORD_TOKEN` no ambiente e execute `npm run deploy:commands`.

## Dono Supremo
O ID configurado inicialmente está em `src/config/constants.js`. Ele recebe privilégios administrativos **dentro do bot** e é ignorado pelas punições implementadas pelo próprio bot. Isso não altera a propriedade real dos servidores Discord nem impede ações do Discord ou de outros bots.

## Estado do projeto
Esta é uma base inicial funcional, não o sistema completo descrito no README. Módulos como anti-raid, tickets completos, IA, banco de dados e logs avançados ainda precisam ser implementados e testados.
