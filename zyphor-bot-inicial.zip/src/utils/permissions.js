const { OWNER_ID } = require('../config/constants');

function isSupremeOwner(userId) {
  return userId === OWNER_ID;
}

function canManageBot(interaction) {
  return isSupremeOwner(interaction.user.id) ||
    interaction.memberPermissions?.has('Administrator') === true;
}

module.exports = { isSupremeOwner, canManageBot };
