const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'guild-settings.json');

function readAll() {
  try {
    if (!fs.existsSync(DATA_FILE)) return {};
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (error) {
    console.error('Não foi possível ler as configurações salvas:', error);
    return {};
  }
}

function writeAll(data) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const temp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(temp, DATA_FILE);
}

function getGuildSettings(guildId) {
  const all = readAll();
  return all[guildId] || {
    prefix: '.',
    modules: { security: false, moderation: true, tickets: false, welcome: false, logs: false, ai: false }
  };
}

function updateGuildSettings(guildId, patch) {
  const all = readAll();
  const current = all[guildId] || getGuildSettings(guildId);
  all[guildId] = {
    ...current,
    ...patch,
    modules: { ...(current.modules || {}), ...(patch.modules || {}) }
  };
  writeAll(all);
  return all[guildId];
}

module.exports = { getGuildSettings, updateGuildSettings };
