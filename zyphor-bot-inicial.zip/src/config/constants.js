module.exports = {
  // Proprietário administrativo principal do Zyphor Bot.
  // Privilégios aplicam-se aos sistemas do próprio bot.
  OWNER_ID: '1533306874513068093'
};
