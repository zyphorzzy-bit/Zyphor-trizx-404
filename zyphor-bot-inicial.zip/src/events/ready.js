function registerReady(client) {
  client.once('ready', readyClient => {
    console.log(`Zyphor Bot conectado como ${readyClient.user.tag}`);
    console.log(`Servidores conectados: ${readyClient.guilds.cache.size}`);
  });
}
module.exports = { registerReady };
