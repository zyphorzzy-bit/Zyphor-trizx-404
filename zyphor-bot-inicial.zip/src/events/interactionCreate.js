const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { isSupremeOwner, canManageBot } = require('../utils/permissions');
const { getGuildSettings, updateGuildSettings } = require('../config/store');

function registerInteractionCreate(client) {
  client.on('interactionCreate', async interaction => {
    try {
      if (interaction.isChatInputCommand()) {
        if (interaction.commandName === 'ping') {
          return interaction.reply({ content: `Pong! Latência: ${client.ws.ping} ms`, flags: MessageFlags.Ephemeral });
        }
        if (interaction.commandName === 'config') {
          if (!interaction.guild) {
            return interaction.reply({ content: 'Use este comando dentro de um servidor.', flags: MessageFlags.Ephemeral });
          }
          if (!canManageBot(interaction)) {
            return interaction.reply({ content: 'Você não tem permissão para abrir este painel.', flags: MessageFlags.Ephemeral });
          }
          const settings = getGuildSettings(interaction.guild.id);
          const embed = new EmbedBuilder()
            .setColor(0x292929)
            .setTitle('Zyphor Bot • Configuração')
            .setDescription('Esta é a base inicial do painel. Escolha um módulo para ativar ou desativar.')
            .addFields(
              { name: 'Segurança', value: settings.modules.security ? 'Ativada' : 'Desativada', inline: true },
              { name: 'Moderação', value: settings.modules.moderation ? 'Ativada' : 'Desativada', inline: true },
              { name: 'Tickets', value: settings.modules.tickets ? 'Ativados' : 'Desativados', inline: true },
              { name: 'Boas-vindas', value: settings.modules.welcome ? 'Ativadas' : 'Desativadas', inline: true },
              { name: 'Logs', value: settings.modules.logs ? 'Ativados' : 'Desativados', inline: true },
              { name: 'IA', value: settings.modules.ai ? 'Ativada' : 'Desativada', inline: true }
            )
            .setFooter({ text: `Servidor: ${interaction.guild.name}` });

          const menu = new StringSelectMenuBuilder()
            .setCustomId('zyphor_config_module')
            .setPlaceholder('Escolha um módulo')
            .addOptions(
              { label: 'Segurança', value: 'security', description: 'Ativar ou desativar segurança' },
              { label: 'Moderação', value: 'moderation', description: 'Ativar ou desativar moderação' },
              { label: 'Tickets', value: 'tickets', description: 'Ativar ou desativar tickets' },
              { label: 'Boas-vindas', value: 'welcome', description: 'Ativar ou desativar boas-vindas' },
              { label: 'Logs', value: 'logs', description: 'Ativar ou desativar logs' },
              { label: 'IA', value: 'ai', description: 'Ativar ou desativar IA' }
            );
          const row = new ActionRowBuilder().addComponents(menu);
          return interaction.reply({ embeds: [embed], components: [row], flags: MessageFlags.Ephemeral });
        }
      }

      if (interaction.isStringSelectMenu() && interaction.customId === 'zyphor_config_module') {
        if (!interaction.guild || !canManageBot(interaction)) {
          return interaction.reply({ content: 'Você não tem permissão para alterar o painel.', flags: MessageFlags.Ephemeral });
        }
        const moduleName = interaction.values[0];
        const settings = getGuildSettings(interaction.guild.id);
        const enabled = !settings.modules[moduleName];
        updateGuildSettings(interaction.guild.id, { modules: { [moduleName]: enabled } });
        return interaction.update({
          content: `Módulo **${moduleName}** ${enabled ? 'ativado' : 'desativado'} na configuração inicial.`,
          embeds: [],
          components: []
        });
      }
    } catch (error) {
      console.error('Erro ao processar interação:', error);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: 'Ocorreu um erro ao processar essa ação.', flags: MessageFlags.Ephemeral }).catch(() => {});
      }
    }
  });
}
module.exports = { registerInteractionCreate };
